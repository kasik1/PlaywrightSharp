import configparser
import json
import sys

def parse_ini(file_path):
    #Initialize the submodules parser
    config = configparser.ConfigParser()

    #Read the ini file
    config.read(file_path)

    submodules = []

    for section in config.sections():
        if "submodule" in section: 
            name = section.split('"')[1]
            path = config[section]['path']
            ignore_install_error = config[section]['ignore-install-error']
            submodules.append({'name': name, 'path': path, 'ignore_install_error': ignore_install_error})
    
    print(json.dumps(submodules))

if __name__ == "__main__":
    if len(sys.argv) > 1:
        ini_file_path = sys.argv[1]
        parse_ini(ini_file_path)
    else:
        print("Please provide the path to the .ini file.")
        sys.exit(1)