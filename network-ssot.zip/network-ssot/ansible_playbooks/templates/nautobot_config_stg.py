import os
import sys
from ndosecrets import get_secret, get_local_secret
from nautobot.core.settings import *  # noqa F401,F403
from nautobot.core.settings_funcs import is_truthy, parse_redis_connection

NAUTOBOT_ENVIRONMENT = get_local_secret("environment")
VAULT_SETTINGS = get_secret(f"ssot/environment/{NAUTOBOT_ENVIRONMENT}")

ALLOWED_HOSTS = VAULT_SETTINGS.get("NAUTOBOT_ALLOWED_HOSTS", "*").split(" ")
CSRF_TRUSTED_ORIGINS = ['https://*.sys.cigna.com','http://*.silver.com']

CACHES = {
    "default": {
        "BACKEND": VAULT_SETTINGS.get(
            "NAUTOBOT_CACHES_BACKEND",
            "django_prometheus.cache.backends.redis.RedisCache",
        ),
        "LOCATION": "redis://cvlappxd35875.silver.com:6379/1",
        "TIMEOUT": 300,
        "OPTIONS": {
            "CLIENT_CLASS": "django_redis.client.DefaultClient",
            "PASSWORD": "",
        },
    }
}
CELERY_BROKER_URL = VAULT_SETTINGS.get("NAUTOBOT_CELERY_BROKER_URL", "redis://cvlappxd35875.silver.com:6379/2")

DATABASES = {
    "default": {
        "NAME":     VAULT_SETTINGS.get("NAUTOBOT_DB_NAME",     "ssot_stg_db"),  # Database name
        "USER":     VAULT_SETTINGS.get("NAUTOBOT_DB_USER",     ""),  # Database username
        "PASSWORD": VAULT_SETTINGS.get("NAUTOBOT_DB_PASSWORD", ""),  # Database password
        "HOST":     VAULT_SETTINGS.get("NAUTOBOT_DB_HOST",     "cvlpsqld20235.silver.com"),  # Database server
        "PORT":     VAULT_SETTINGS.get("NAUTOBOT_DB_PORT",     "5432"),  # Database port (leave blank for default)
        "CONN_MAX_AGE": int(os.getenv("NAUTOBOT_DB_TIMEOUT", "300")),  # Database timeout
        "ENGINE": "django_prometheus.db.backends.postgresql",
        'OPTIONS': {
            'options': '-c search_path=appschema'
        },
    }
}

SECRET_KEY = VAULT_SETTINGS.get("NAUTOBOT_SECRET_KEY", "")

DEBUG = is_truthy(VAULT_SETTINGS.get("NAUTOBOT_DEBUG", "True"))

INTERNAL_IPS = ("127.0.0.1", "::1")

NAUTOBOT_ROOT = VAULT_SETTINGS.get("NAUTOBOT_ROOT","/opt/nautobot/nautobot")
GIT_ROOT = VAULT_SETTINGS.get("GIT_ROOT","/opt/nautobot/nautobot/git")
MEDIA_ROOT = os.path.join(NAUTOBOT_ROOT, "media").rstrip("/")
STATIC_ROOT = os.path.join(NAUTOBOT_ROOT, "static")
TIME_ZONE = VAULT_SETTINGS.get("NAUTOBOT_TIME_ZONE", "UTC")
BRANDING_TITLE = VAULT_SETTINGS.get("NAUTOBOT_BRANDING_TITLE", "Network SSoT")

EMAIL_HOST = 'testrelay.silver.com'
DEFAULT_FROM_EMAIL = 'Network SSoT <donotreply@cigna.com>'
EMAIL_HOST_PASSWORD = VAULT_SETTINGS.get("EMAIL_HOST_PASSWORD", "")
EMAIL_HOST_USER = VAULT_SETTINGS.get("EMAIL_HOST_USER", "")
EMAIL_PORT = 465
EMAIL_USE_TLS = True

CHANGELOG_RETENTION = 0
SESSION_COOKIE_AGE=900
SESSION_EXPIRE_AT_BROWSER_CLOSE=True
SESSION_SAVE_EVERY_REQUEST=True
SESSION_ENGINE="django.contrib.sessions.backends.cache"

PLUGINS = ['nautobot_ssot',
           'nautobot_secrets_providers',
           'nautobot_bgp_models',
           'nautobot_firewall_models',
           'nautobot_device_lifecycle_mgmt',
           'nautobot_data_validation_engine',
           'nautobot_chatops',
           'nautobot_golden_config',
           'nautobot_ssot_cigna',
           'nautobot_asset_management_cigna',
           'nautobot_cigna_deviceindicator',
           'nautobot_cigna_qsrreport',
           'nautobot_cigna_contracts',
           'ssot_telemetry',
           'nautobot_servicenow_cigna']

PLUGINS_CONFIG = {
    'nautobot_secrets_providers': {
        "hashicorp_vault": {
            "url":          os.getenv("VAULT_URL","https://ndovault.sys.cigna.com/"),
            "auth_method":  os.getenv("VAULT_AUTH_METHOD","approle"),
            "role_id":      VAULT_SETTINGS.get("VAULT_ROLE_ID",""),
            "secret_id":    VAULT_SETTINGS.get("VAULT_SECRET_ID", ""),
            "ca_cert":      False,
        },

    },
    "nautobot_golden_config": {
        "enable_backup": False,
        "enable_deploy": False,
        "enable_sotagg": True,
    },
    'nautobot_ssot': {
        'hide_example_jobs':    False,
        'enable_ipfabric':      False,
        'enable_aci':           False,
        # Infoblox
        'enable_infoblox': True,
        "infoblox_default_status": "active",
        "infoblox_enable_rfc1918_network_containers": False,
        "infoblox_enable_sync_to_infoblox": False,
        "infoblox_import_objects_ip_addresses": True,
        "infoblox_import_objects_subnets": True,
        "infoblox_import_objects_subnets_ipv6": True,
        "infoblox_import_objects_vlan_views": False,
        "infoblox_import_objects_vlans": True,
        "infoblox_import_subnets": "",
        "infoblox_password": VAULT_SETTINGS.get("INFOBLOX_PASS",""),
        "infoblox_url": "https://dns-dhcp.sys.cigna.com/",
        "infoblox_username": VAULT_SETTINGS.get("INFOBLOX_USER",""),
        "infoblox_verify_ssl": False,
        "infoblox_wapi_version": "v2.7.3",
        "infoblox_network_view": [],
    },
    'nautobot_servicenow_cigna': {
        'servicenow_transport': 'https',
        'servicenow_hostname': 'cignadev1.service-now.com',
        'servicenow_username': VAULT_SETTINGS.get("SERVICENOW_USER",""),
        'servicenow_password': VAULT_SETTINGS.get("SERVICENOW_PASS",""),
        'servicenow_environment': 'Development',
        'ip_fabric_hostname': '10.162.16.76',
        'ip_fabric_api_version': 'v6',
        'ip_fabric_token': VAULT_SETTINGS.get("IPFABRIC_TOKEN",""),
        'itential_hostname': 'https://itential.prd.globalcore.com',
        'itential_username': VAULT_SETTINGS.get("ITENTIAL_USERNAME",""),
        'itential_password': VAULT_SETTINGS.get("ITENTIAL_PASSWORD",""),
        'aap_hostname': 'https://ansibletower.sys.cigna.com/api/v2/',
        'aap_ops_ready_id': VAULT_SETTINGS.get("AAP_OPS_READY_ID", ""),
        'aap_token': VAULT_SETTINGS.get("AAP_TOKEN", ""),
        'webex_token': VAULT_SETTINGS.get("WEBEX_TOKEN", ""),
        'webex_url': 'https://webexapis.com',
        'webex_room_id': VAULT_SETTINGS.get("WEBEX_ROOM_ID", "")
    },
    'nautobot_ssot_cigna': {
        'enable_integration_ipfabric': True, # Enable customized IPFabric integration
        "ipfabric_api_token": VAULT_SETTINGS.get("IPFABRIC_TOKEN",""),
        "ipfabric_host": "https://10.162.16.76",
        "ipfabric_ssl_verify": False,
        "ipfabric_use_canonical_interface_name": True,
        "ipfabric_timeout": 60,
        "nautobot_host": "https://networkssot.sys.cigna.com",

        # SevOne
        'enable_sevone': True,
        'sevone_limit_pages': 1,
        'sevone_servers': [
            {
                "url": "https://sevone.sys.cigna.com",
                "secret_name": None,
                "username": VAULT_SETTINGS.get("SEVONE_USER",""),
                "password": VAULT_SETTINGS.get("SEVONE_PASS",""),
            },
            # {
            #     "url": "https://ps2pa1004626-1.express-scripts.com",
            #     "secret_name": None,
            #     "username": "",
            #     "password": "",
            # },
        ],

        # Netbox (NIM)
        'enable_netbox': True,
        'netbox_servers': [
            {
                "url": "https://nim.sys.cigna.com",
                "token": VAULT_SETTINGS.get("NIM_TOKEN",""),
                "ssl_verify": False,
                "timeout": (5,60)
            }
        ],

        # ServiceNow
        'enable_servicenow': True,
        'servicenow_transport': 'https',
        'servicenow_hostname': 'cigna.service-now.com',
        'servicenow_username': VAULT_SETTINGS.get("SERVICENOW_USER",""),
        'servicenow_password': VAULT_SETTINGS.get("SERVICENOW_PASS",""),

        # Assure1
        'enable_assure1': True,
        'assure1_transport': 'https',
        'assure1_hostname': 'cilappxp0471.sys.cigna.com',
        'assure1_username': VAULT_SETTINGS.get("ASSURE1_USER",""),
        'assure1_password': VAULT_SETTINGS.get("ASSURE1_PASS",""),

        'enable_qsr': True,

        'qsr_infoblox_hostname': 'https://dns-dhcp.sys.cigna.com/wapi/v2.11/zone_auth?'
                                 '_return_as_object=1&_paging=1&_max_results=10000&view=Cigna%20Internal',
        "qsr_infoblox_username": VAULT_SETTINGS.get("INFOBLOX_USER", ""),
        'qsr_infoblox_password': VAULT_SETTINGS.get("INFOBLOX_PASS", ""),

        # Infoblox FQDN
        'enable_check_infoblox_records': True,
        "fqdn_infoblox_password": VAULT_SETTINGS.get("INFOBLOX_PASS", ""),
        "fqdn_infoblox_url": "https://dns-dhcp.sys.cigna.com",
        "fqdn_infoblox_username": VAULT_SETTINGS.get("INFOBLOX_USER", ""),
        "fqdn_infoblox_wapi_version": "v2.7.3",
        "fqdn_infoblox_view": "Cigna%20Internal",

        # Global configuration
        'delete_devices_on_sync': False,
        'default_site': 'DefaultSite',
        'default_status': 'Active',
        'default_device_role': 'DefaultRole',
        'apply_import_tag': True,
        'import_active': True,
    },
    'ssot_telemetry': {
        'telemetry_log_file': '/opt/nautobot/logs/ssot_telemetry.log',
        'log_level': 'DEBUG',
        'maxBytes': 1024 * 1024 * 5,
        'backupCount': 5
    },
    "nautobot_cigna_itential": {
        "itential_username": VAULT_SETTINGS.get("ITENTIAL_USERNAME", ""),
    },
    'nautobot_cigna_deviceindicator': {
        # Missing Devices Report
        'enable_report_for_missing_devices': True,
        'servicenow_transport': 'https',
        'servicenow_hostname': 'cignadev1.service-now.com',
        'servicenow_username': VAULT_SETTINGS.get("SERVICENOW_USER", ""),
        'servicenow_password': VAULT_SETTINGS.get("SERVICENOW_PASS", ""),
    },
}

PREFER_IPV4 = True

AUTHENTICATION_BACKENDS = [
    "social_core.backends.okta_openidconnect.OktaOpenIdConnect",
    "nautobot.core.authentication.ObjectPermissionBackend",
]

SOCIAL_AUTH_OKTA_OPENIDCONNECT_KEY = VAULT_SETTINGS.get("SOCIAL_AUTH_OKTA_OPENIDCONNECT_KEY", "")
SOCIAL_AUTH_OKTA_OPENIDCONNECT_SECRET = VAULT_SETTINGS.get("SOCIAL_AUTH_OKTA_OPENIDCONNECT_SECRET", "")
SOCIAL_AUTH_OKTA_OPENIDCONNECT_API_URL = 'https://cigna.oktapreview.com/oauth2/'
SOCIAL_AUTH_OKTA_OPENIDCONNECT_SCOPE = ['groups']
SOCIAL_AUTH_REDIRECT_IS_HTTPS = True
SOCIAL_AUTH_PIPELINE = (
    "social_core.pipeline.social_auth.social_details",
    "social_core.pipeline.social_auth.social_uid",
    "social_core.pipeline.social_auth.auth_allowed",
    "social_core.pipeline.social_auth.social_user",
    "social_core.pipeline.debug.debug",
    "social_core.pipeline.user.get_username",
    "social_core.pipeline.user.create_user",
    "social_core.pipeline.social_auth.associate_user",
    "social_core.pipeline.social_auth.load_extra_data",
    "social_core.pipeline.user.user_details",
    "social_core.pipeline.debug.debug",
    "nautobot_okta_sync.okta.group_sync",
)


log_file = getattr(PLUGINS_CONFIG['ssot_telemetry'], 'telemetry_log_file', '/opt/nautobot/logs/ssot-telemetry.log')
log_level = getattr(PLUGINS_CONFIG['ssot_telemetry'], 'log_level', 'DEBUG')
maxBytes = getattr(PLUGINS_CONFIG['ssot_telemetry'], 'maxBytes', 1024*1024*5) # Default 5MB
backupCount = getattr(PLUGINS_CONFIG['ssot_telemetry'], 'backupCount', 5)

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "normal": {
            "format": "%(asctime)s.%(msecs)03d %(levelname)-7s %(name)s :\n  %(message)s",
            "datefmt": "%H:%M:%S",
        },
        "verbose": {
            "format": "%(asctime)s.%(msecs)03d %(levelname)-7s %(name)-20s %(filename)-15s %(funcName)30s() :\n  %(message)s",
            "datefmt": "%H:%M:%S",
        },
        'standard':{
            'format': '%(asctime)s %(levelname)s %(name)s: %(message)s'
        },
    },
    "handlers": {
        "normal_console": {
            "level": "INFO",
            "class": "logging.StreamHandler",
            "formatter": "normal",
        },
        "verbose_console": {
            "level": "DEBUG",
            "class": "logging.StreamHandler",
            "formatter": "verbose",
        },
        "telemetry_file":{
            'level': log_level,
            'class': 'logging.handlers.RotatingFileHandler',
            'filename':log_file,
            'maxBytes': maxBytes,
            'backupCount': backupCount,
            'formatter': 'standard'
        },

    },
    "loggers": {
        "django": {"handlers": ["normal_console"], "level": "INFO"},
        "nautobot": {
            "handlers": ["verbose_console" if DEBUG else "normal_console"],
            "level": "DEBUG" if DEBUG else "INFO",
        },
        'ssot-telemetry':{
            'handlers': ['telemetry_file'],
            'level': log_level,
            'propagate': True,
        },
    },
}
