from ..endpoints.base_endpoint import BaseEndPoint


class Tenancy(BaseEndPoint):
    def __init__(self, session, server_url, **kwargs):
        super(Tenancy, self).__init__(session, server_url, **kwargs)