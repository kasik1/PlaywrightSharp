from ..endpoints.base_endpoint import BaseEndPoint


class Plugins(BaseEndPoint):
    def __init__(self, session, server_url, **kwargs):
        super(Plugins, self).__init__(session, server_url, **kwargs)