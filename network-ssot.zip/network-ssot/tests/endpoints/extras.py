from ..endpoints.base_endpoint import BaseEndPoint
import requests


class Extras(BaseEndPoint):
    def __init__(self, session, server_url, **kwargs):
        super(Extras, self).__init__(session, server_url, **kwargs)

    def post_with_image(self, *args, **kwargs):
        """
        :param args: Contains the path parameters
        :param kwargs: Contains the query parameters
        :return: Request response
        """
        request_url = self.format_url(self.endpoint).format(*args)
        files = {}
        """
        If there's an API Token, self.session will not be used because it will create an authentication problem
        """
        if 'Authorization' in self.headers and self.headers['Authorization'] != '':
            if self.attachment_file_path is not None and self.attachment_file_name is not None:
                files = {self.attachment_file_name: open(self.attachment_file_path, mode='rb')}
            return requests.post(request_url, data=self.body_request, headers=self.headers, verify=False, files=files)
        else:
            return self.session.post(request_url, json=self.body_request, headers=self.headers)

    def put_with_image(self, *args, **kwargs):
        """
        :param args: Contains the path parameters
        :param kwargs: Contains the query parameters
        :return: Request response
        """
        request_url = self.format_url(self.endpoint).format(*args)
        files = {}
        """
        If there's an API Token, self.session will not be used because it will create an authentication problem
        """
        if 'Authorization' in self.headers and self.headers['Authorization'] != '':
            if self.attachment_file_path is not None and self.attachment_file_name is not None:
                files = {self.attachment_file_name: open(self.attachment_file_path, mode='rb')}
            return requests.put(request_url, data=self.body_request, headers=self.headers, verify=False, files=files)
        else:
            return self.session.put(request_url, data=self.body_request, headers=self.headers)

    def patch_with_image(self, *args, **kwargs):
        """
        :param args: Contains the path parameters
        :param kwargs: Contains the query parameters
        :return: Request response
        """
        request_url = self.format_url(self.endpoint).format(*args)
        files = {}
        """
        If there's an API Token, self.session will not be used because it will create an authentication problem
        """
        if 'Authorization' in self.headers and self.headers['Authorization'] != '':
            if self.attachment_file_path is not None and self.attachment_file_name is not None:
                files = {self.attachment_file_name: open(self.attachment_file_path, mode='rb')}
            return requests.patch(request_url, data=self.body_request, headers=self.headers, verify=False, files=files)
        else:
            return self.session.patch(request_url, data=self.body_request, headers=self.headers)
