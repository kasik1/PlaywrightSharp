from ..endpoints.base_endpoint import BaseEndPoint


class Status(BaseEndPoint):
    def __init__(self, session, server_url, **kwargs):
        super(Status, self).__init__(session, server_url, **kwargs)