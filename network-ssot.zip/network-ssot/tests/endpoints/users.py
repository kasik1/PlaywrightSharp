from ..endpoints.base_endpoint import BaseEndPoint


class Users(BaseEndPoint):
    def __init__(self, session, server_url, **kwargs):
        super(Users, self).__init__(session, server_url, **kwargs)