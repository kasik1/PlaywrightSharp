import pytest


@pytest.mark.smoke
class TestPrefixesSmokeTesting:
    @pytest.mark.parametrize('test_data', ['test_get_prefix'], indirect=True)
    def test_get_prefix(self, http, test_data, response_results, response_asserts, response_assert_fields, apikey):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        response_fields = ['results']
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(end_point)
            module.set_headers(header)
            response = module.get()
            response_results(response)
            response_asserts(response)
            response_assert_fields(response, response_fields)


@pytest.mark.parallel
@pytest.mark.functional
class TestPrefixes:

    def setup(self):
        self.url_prefix = '/api/ipam/prefixes/'
        self.status = "Active"

    @staticmethod
    def create_entry_for_testing(http, row, end_point, apikey, return_id=True):
        """ This method creates the payload to be sent in the rquest of the following test cases,
                Payload : is the set of data that will be sent to generate the intake ticket
                Module : contains the instruction for the execution of the method to be carried out, example: post (), get () etc.
                Response : contains the response after the post was executed, or get
                Create an if : this looks for the id tag in the respons to check that the pyload was generated correctly"""
        module = http(end_point)
        header = {"Authorization": f'{apikey}',
                  'Content-type': 'application/json'}
        payload = {
            "prefix": row['prefix'],
            "status": "Active",
            "description":  row['desc']
        }
        module.set_headers(header)
        module.set_body(payload)
        response = module.post()
        if return_id:
            assert 'id' in response.json(), "New Automation Request entry for testing was not created successfully."
            return response.json()['id']

    @pytest.mark.parametrize('test_data', ['test_get_prefix_id'], indirect=True)
    def test_get_prefix_id(self, http, test_data, response_results, response_asserts, response_assert_fields, apikey,
                           get_object_id):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        response_fields = ['id', 'prefix', 'description', 'status']
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_prefix)
            module.set_headers(header)
            response = module.get()
            if not response.json()['results']:
                self.create_entry_for_testing(http, row, '/api/ipam/prefixes/',
                                              apikey=apikey)
            get_id = get_object_id(module)
            module = http(end_point)
            module.set_headers(header)
            response = module.get(get_id)
            response_results(response, print_json_rows=False)
            response_asserts(response)
            response_assert_fields(response, response_fields)

    @pytest.mark.parametrize('test_data', ['test_get_prefix_available_id'], indirect=True)
    def test_get_prefix_available_id(self, http, test_data, response_results, response_asserts, response_assert_fields,
                                     apikey,
                                     get_object_id):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_prefix)
            module.set_headers(header)
            response = module.get()
            if not response.json()['results']:
                self.create_entry_for_testing(http, row, '/api/ipam/prefixes/',
                                              apikey=apikey)
            get_id = get_object_id(module)
            module = http(end_point)
            module.set_headers(header)
            response = module.get(get_id)
            response_results(response, print_json_rows=False)
            response_asserts(response)

    @pytest.mark.parametrize('test_data', ['test_get_prefix_available_prefix'], indirect=True)
    def test_get_prefix_available_prefix(self, http, test_data, response_results, response_asserts,
                                         response_assert_fields, apikey,
                                         get_object_id):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_prefix)
            module.set_headers(header)
            response = module.get()
            if not response.json()['results']:
                self.create_entry_for_testing(http, row, '/api/ipam/prefixes/',
                                              apikey=apikey)
            get_id = get_object_id(module)
            module = http(end_point)
            module.set_headers(header)
            response = module.get(get_id)
            response_results(response, print_json_rows=False)
            response_asserts(response)

    @pytest.mark.parametrize('test_data', ['test_post_create_prefix'], indirect=True)
    def test_post_create_prefix(self, http, test_data, response_results, apikey, response_asserts,
                                            response_assert_fields):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            module = http(end_point)
            header = {"Authorization": f'{apikey}',
                'Content-type': 'application/json'}
            payload = {
                "prefix": row['prefix'],
                "status": self.status,
                "description":  row['desc']
            }
            module.set_body(payload)
            module.set_headers(header)
            response = module.post()
            response_results(response, print_json_rows=False)
            response_asserts(response, status_code=201)
            response_assert_fields(response, payload)
            object_id = response.json()['id']
            get_end_point = '/api/ipam/prefixes/{}/'.format(object_id)
            module = http(get_end_point)
            module.set_headers(header)
            response = module.delete(object_id)
            response_results(response, print_json=False, print_content_type=False)
            response_asserts(response, status_code=204, assert_json=False, assert_content_type=False)

    @pytest.mark.parametrize('test_data', ['test_post_create_prefix_ips'], indirect=True)
    def test_post_create_prefix_ips(self, http, test_data, response_results, apikey, response_asserts,
                                    response_assert_fields):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {"Authorization": f'{apikey}',
                      'Content-type': 'application/json'}
            object_id = self.create_entry_for_testing(http, row, '/api/ipam/prefixes/', apikey=apikey)
            payload = [
                {
                    "status": self.status,
                    "vrf": {
                        "name": "test",
                        "rd": "test"
                    }
                }
            ]
            module = http(end_point)
            module.set_body(payload)
            module.set_headers(header)
            response = module.post(object_id)
            id_ip = response.json()[0]['id']
            response_results(response, print_json=False, print_content_type=False)
            get_end_point = '/api/ipam/ip-addresses/{}/'.format(id_ip)
            module = http(get_end_point)
            module.set_headers(header)
            response = module.delete(id_ip)
            response_asserts(response, status_code=204, assert_json=False, assert_content_type=False)
            get_end_point = '/api/ipam/prefixes/{}/'.format(object_id)
            module = http(get_end_point)
            module.set_headers(header)
            response = module.delete(object_id)
            response_results(response, print_json=False, print_content_type=False)
            response_asserts(response, status_code=204, assert_json=False, assert_content_type=False)

    @pytest.mark.parametrize('test_data', ['test_post_create_prefix_available'], indirect=True)
    def test_post_create_prefix_available(self, http, test_data, response_results, apikey, response_asserts,
                                          response_assert_fields):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {"Authorization": f'{apikey}',
                      'Content-type': 'application/json'}
            object_id = self.create_entry_for_testing(http, row, '/api/ipam/prefixes/', apikey=apikey)
            print("ob",object_id)
            payload = {
                "prefix_length": 27,
                "status": self.status,

            }
            module = http(end_point)
            module.set_body(payload)
            module.set_headers(header)
            response = module.post(object_id)
            prefix_id = response.json()['id']
            response_asserts(response, status_code=201)
            for id in [object_id, prefix_id]:
                get_end_point = '/api/ipam/prefixes/{}/'
                module = http(get_end_point)
                module.set_headers(header)
                response = module.delete(id)
                response_results(response, print_json=False, print_content_type=False)
                response_asserts(response, status_code=204, assert_json=False, assert_content_type=False)


    @pytest.mark.parametrize('test_data', ['test_put_update_prefix'], indirect=True)
    def test_put_update_prefix(self, http, test_data, response_results, get_object_id, apikey, get_object_data):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_results: Fixture that will print information about the Test
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {"Authorization": f'{apikey}'}
            module = http(self.url_prefix)
            module.set_headers(header)
            get_id = get_object_id(module)
            get_prefix = get_object_data(module, "prefix")
            module = http(end_point)
            payload = [{
                "id": get_id,
                "prefix": get_prefix,
                "status": self.status,
                "description": row['desc']
            }]
            module.set_headers(header)
            module.set_body(payload)
            response = module.put()
            response_results(response, print_json_rows=False)
            assert response.json()[0]['id'] == get_id, f"ID from response does not match expected ID {get_id}."
            assert response.json()[0]['prefix'] == get_prefix, f"Prefix from response does not match expected Prefix{get_prefix}."

    @pytest.mark.parametrize('test_data', ['test_put_update_prefix_id'], indirect=True)
    def test_put_update_prefix_id(self, http, test_data, response_results, response_asserts,
                                           response_assert_fields, get_object_id, apikey, get_object_data):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_prefix)
            module.set_headers(header)
            get_id = get_object_id(module)
            get_prefix = get_object_data(module, "prefix")
            module = http(end_point)
            payload = {
                "prefix": get_prefix,
                "status": self.status,
                "description": row['desc']
            }
            module.set_headers(header)
            module.set_body(payload)
            response = module.put(get_id)
            response_results(response, print_json_rows=False)
            response_asserts(response)
            response_assert_fields(response, payload)
            assert response.json()['prefix'] == get_prefix, f"Prefix from response does not match expected Prefix {get_prefix}."
            assert response.json()['id'] == get_id, f" ID from response does not match expected ID{get_id}."

    @pytest.mark.parametrize('test_data', ['test_patch_update_prefix'], indirect=True)
    def test_patch_update_prefix(self, http, test_data, response_results, get_object_id, get_object_data, apikey):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_results: Fixture that will print information about the Test
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_prefix)
            module.set_headers(header)
            get_id = get_object_id(module)
            get_prefix = get_object_data(module, "prefix")
            module = http(end_point)
            payload = [{
                "id": get_id,
                "prefix": get_prefix,
                "status": self.status,
                "description": row['desc']}]
            module.set_headers(header)
            module.set_body(payload)
            response = module.put()
            response_results(response, print_json_rows=False)
            assert response.json()[0]['id'] == get_id, f"ID from response does not match expected ID {get_id}."
            assert response.json()[0]['prefix'] == get_prefix, f"Prefix from response does not match expected Prefix{get_prefix}."

    @pytest.mark.parametrize('test_data', ['test_patch_update_prefix_id'], indirect=True)
    def test_patch_update_prefix_id(self, http, test_data, response_results, response_asserts,
                                   response_assert_fields, get_object_id, apikey, get_object_data):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_prefix)
            module.set_headers(header)
            get_id = get_object_id(module)
            get_prefix = get_object_data(module, "prefix")
            module = http(end_point)
            payload = {
                "prefix": get_prefix,
                "status": self.status,
                "description": row['desc']
            }
            module.set_headers(header)
            module.set_body(payload)
            response = module.put(get_id)
            response_results(response, print_json_rows=False)
            response_asserts(response)
            response_assert_fields(response, payload)
            assert response.json()['prefix'] == get_prefix, f"Prefix from response does not match expected Prefix {get_prefix}."
            assert response.json()['id'] == get_id, f" ID from response does not match expected ID{get_id}."

    @pytest.mark.parametrize('test_data', ['test_delete_prefix'], indirect=True)
    def test_delete_prefix(self, http, test_data, response_results, response_asserts,
                                       response_assert_fields,apikey):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            header = {"Authorization": f'{apikey}'}
            object_id = self.create_entry_for_testing(http, row, '/api/ipam/prefixes/', apikey=apikey)
            end_point = row['ENDPOINT']
            module = http(end_point)
            module.set_headers(header)
            response = module.delete(object_id)
            response_results(response, print_json=False, print_content_type=False)
            response_asserts(response, status_code=204, assert_json=False, assert_content_type=False)

            get_end_point = '/api/ipam/prefixes/{}/'.format(object_id)
            module = http(get_end_point)
            module.set_headers(header)
            response = module.get(object_id)
            assert response.status_code == 404, "The status code not is equal at 404"
            assert response.json()['detail'] == 'No Prefix matches the given query.', "The Request wasn't deleted."
