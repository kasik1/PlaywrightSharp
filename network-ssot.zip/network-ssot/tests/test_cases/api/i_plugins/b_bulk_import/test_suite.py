import pytest


@pytest.mark.parallel
@pytest.mark.functional
class TestBulk:

    def setup(self):
        self.url_bulk = '/api/plugins/ssot-cigna/custom-device-bulk-import/'
        self.url_device = '/api/dcim/devices/'

    @staticmethod
    def get_object_id(http, apikey, end_point, search):
        header = {"Authorization": f'{apikey}'}
        module = http(end_point)
        module.set_headers(header)
        response = module.get(f"?{search}")
        assert 'results' in response.json(), "Object was not found"
        id = response.json()['results'][0]['id']
        return id

    @pytest.mark.parametrize('test_data', ['test_post_create_bulk'], indirect=True)
    def test_post_create_bulk(self, http, test_data, response_results, apikey, response_asserts,
                                            response_assert_fields):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            module = http(end_point)
            header = {"Authorization": f'{apikey}',
                'Content-type': 'application/json'}
            payload = {
            "devices":  [
                {
                    "name": "Router1",
                    "serial": "TEST12345",
                    "device_type__model": "Test-Device type 01",
                    "location__name": "QA-TD Location - update",
                    "status__name": "Active",
                    "role__name": "Test-Device Role 01",
                    "cf_servicenow_assignment_group": "GNS Remote Connectivity Engineering",
                    "cf_servicenow_device_type": "Load Balancer",
                    "interface__name": "Eth0",
                    "ip_address": "10.1.1.1/32"
                },
                {
                    "name": "Router2",
                    "serial": "2TEST12345",
                    "device_type__model": "Test-Device type 01",
                    "location__name": "QA-TD Location - update",
                    "status__name": "Active",
                    "role__name": "Test-Device Role 01",
                    "cf_servicenow_assignment_group": "GNS Remote Connectivity Engineering",
                    "cf_servicenow_device_type": "Load Balancer",
                    "interface__name": "Eth0",
                    "ip_address": "10.1.1.2/32"
                },
            ]
            }
            module.set_body(payload)
            module.set_headers(header)
            response = module.post()
            print(response.json())
            response_results(response, print_json_rows=False)
            response_asserts(response, status_code=200)
            len_response = len(response.json())
            array = []
            for i in range(0, len_response):
                status = response.json()[i]['status']
                name = response.json()[i]['device']
                assert status == "success"
                array.append(name)
            for i in array:
                get_id = self.get_object_id(http, apikey, self.url_device + '{}',
                                            f"name={i}")
                get_end_point = self.url_device + f'{get_id}/'
                module = http(get_end_point)
                module.set_headers(header)
                response = module.delete(get_id)
                response_results(response, print_json=False, print_content_type=False)
                response_asserts(response, status_code=204, assert_json=False, assert_content_type=False)

    @pytest.mark.parametrize('test_data', ['test_post_false_create_bulk'], indirect=True)
    def test_post_false_create_bulk(self, http, test_data, response_results, apikey, response_asserts,
                                            response_assert_fields):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            module = http(end_point)
            header = {"Authorization": f'{apikey}',
                'Content-type': 'application/json'}
            payload = {
            "devices":  [
                {
                    "name": "Router1",
                    "device_type__model": "Test-Device type 01",
                    "location__name": "QA-TD Location - update",
                    "status__name": "Active",
                    "role__name": "Test-Device Role 01",
                    "cf_servicenow_assignment_group": "GNS Remote Connectivity Engineering",
                    "cf_servicenow_device_type": "Load Balancer",
                },
                {
                    "name": "Router2",
                    "device_type__model": "Test-Device type 01",
                    "location__name": "QA-TD Location - update",
                    "status__name": "Active",
                    "role__name": "Test-Device Role 01",
                    "cf_servicenow_assignment_group": "GNS Remote Connectivity Engineering",
                    "cf_servicenow_device_type": "Load Balancer",
                },
            ]
            }
            module.set_body(payload)
            module.set_headers(header)
            response = module.post()
            print(response.json())
            response_results(response, print_json_rows=False)
            response_asserts(response, status_code=200)
            len_response = len(response.json())
            for i in range(0, len_response):
                status = response.json()[i]['status']
                assert status == "error"

