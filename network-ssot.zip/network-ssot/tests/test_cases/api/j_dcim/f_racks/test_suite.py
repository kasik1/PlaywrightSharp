import pytest


@pytest.mark.smoke
class TestRacksSmokeTesting:

    def setup(self):
        self.url_racks = '/api/dcim/racks/'

    @pytest.mark.parametrize('test_data', ['test_get_racks'], indirect=True)
    def test_get_racks(self, http, test_data, response_results, response_asserts, response_assert_fields, apikey):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        response_fields = ['results']
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(end_point)
            module.set_headers(header)
            response = module.get()
            response_results(response)
            response_asserts(response)
            response_assert_fields(response, response_fields)

    @pytest.mark.parametrize('test_data', ['test_get_racks_id'], indirect=True)
    def test_get_racks_id(self, http, test_data, response_results, response_asserts, response_assert_fields, apikey, get_object_id):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        response_fields = ['id', 'url', 'created']
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_racks)
            module.set_headers(header)
            response = module.get()
            if response.json()['results']:
                get_id_racks = get_object_id(module)
                module = http(end_point)
                module.set_headers(header)
                response = module.get(get_id_racks)
                response_results(response, print_json_rows=False)
                response_asserts(response)
                response_assert_fields(response, response_fields)



@pytest.mark.parallel
@pytest.mark.functional
class TestRacks:

    def setup(self):
        self.url_racks = '/api/dcim/racks/'
        self.url_locations = '/api/dcim/locations/'
        self.url_status = '/api/extras/statuses/'

    @staticmethod
    def get_object_id(http, apikey, end_point, search):
        header = {"Authorization": f'{apikey}'}
        module = http(end_point)
        module.set_headers(header)
        response = module.get(f"?{search}")
        assert 'results' in response.json(), "Object was not found"
        id = response.json()['results'][0]['id']
        return id

    @staticmethod
    def create_entry_for_testing(http, row, id_status, end_point, id_location, apikey, return_id=True):
        """ This method creates the payload to be sent in the rquest of the following test cases,
                Payload : is the set of data that will be sent to generate the intake ticket
                Module : contains the instruction for the execution of the method to be carried out, example: post (), get () etc.
                Response : contains the response after the post was executed, or get
                Create an if : this looks for the id tag in the respons to check that the pyload was generated correctly"""
        module = http(end_point)
        header = {"Authorization": f'{apikey}',
                  'Content-type': 'application/json'}
        payload = {
            "name": row['name'],
            "location": id_location,
            "status": id_status,
            "comments": row['comments']
        }
        module.set_headers(header)
        module.set_body(payload)
        response = module.post()
        if return_id:
            assert 'id' in response.json(), "New Automation Request entry for testing was not created successfully."
            return response.json()['id']

    @pytest.mark.parametrize('test_data', ['test_post_create_racks'], indirect=True)
    def test_post_create_racks(self, http, test_data, response_results, apikey, response_asserts,
                                   response_assert_fields, get_object_data):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        id_location = self.get_object_id(http, apikey, self.url_locations + '{}',
                                      "name=QA-TD Location - view")
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {"Authorization": f'{apikey}',
                      'Content-type': 'application/json'}
            module = http(self.url_status)
            module.set_headers(header)
            id_status = get_object_data(module, "id")
            payload = {
                "name": row['name'],
                "location": id_location,
                "status": id_status,
                "comments": row['comments']
            }
            module = http(end_point)
            module.set_body(payload)
            module.set_headers(header)
            response = module.post()
            response_results(response, print_json_rows=False)
            response_asserts(response, status_code=201)
            response_assert_fields(response, payload)
            object_id = response.json()['id']
            get_end_point = '/api/dcim/racks/{}/'.format(object_id)
            module = http(get_end_point)
            module.set_headers(header)
            response = module.delete(object_id)
            response_results(response, print_json=False, print_content_type=False)
            response_asserts(response, status_code=204, assert_json=False, assert_content_type=False)

    @pytest.mark.parametrize('test_data', ['test_put_update_racks'], indirect=True)
    def test_put_update_racks(self, http, test_data, response_results, get_object_id, apikey, get_object_data):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_results: Fixture that will print information about the Test
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_racks)
            module.set_headers(header)
            get_id_racks = get_object_id(module)
            get_name = get_object_data(module, "name")
            get_status = get_object_data(module, "status")
            get_location = get_object_data(module, "location")
            id_location = get_location['id']
            module = http(end_point)
            payload = [{
                "id": get_id_racks,
                "name": get_name,
                "status": get_status,
                "location": id_location,
                "comments": row['comments']
            }]
            module.set_headers(header)
            module.set_body(payload)
            response = module.put()
            response_results(response, print_json_rows=False)
            assert response.json()[0]['id'] == get_id_racks, f"ID from response does not match expected ID {get_id_racks}."
            assert response.json()[0]['name'] == get_name, f"Name from response does not match expected Name{get_name}."

    @pytest.mark.parametrize('test_data', ['test_put_update_racks_id'], indirect=True)
    def test_put_update_racks_id(self, http, test_data, response_results, response_asserts,
                                     response_assert_fields, get_object_id, apikey, get_object_data):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_racks)
            module.set_headers(header)
            get_id_racks = get_object_id(module)
            get_name = get_object_data(module, "name")
            get_status = get_object_data(module, "status")
            get_location = get_object_data(module, "location")
            id_location = get_location['id']
            module = http(end_point)
            payload = {
                "name": get_name,
                "location": id_location,
                "status": get_status,
                "comments": row['comments']
            }
            module.set_headers(header)
            module.set_body(payload)
            response = module.put(get_id_racks)
            response_results(response, print_json_rows=False)
            response_asserts(response)
            response_assert_fields(response, payload)
            assert response.json()['name'] == get_name, f"Name from response does not match expected Name {get_name}."
            assert response.json()['id'] == get_id_racks, f"ID from response does not match expected ID{get_id_racks}."

    @pytest.mark.parametrize('test_data', ['test_patch_update_racks'], indirect=True)
    def test_patch_update_racks(self, http, test_data, response_results, get_object_id, get_object_data, apikey):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_results: Fixture that will print information about the Test
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_racks)
            module.set_headers(header)
            get_id_racks = get_object_id(module)
            get_name = get_object_data(module, "name")
            get_status = get_object_data(module, "status")
            get_location = get_object_data(module, "location")
            id_location = get_location['id']
            module = http(end_point)
            payload = [{
                "id": get_id_racks,
                "name": get_name,
                "location": id_location,
                "status": get_status,
                "comments": row['comments']
            }]
            module.set_headers(header)
            module.set_body(payload)
            response = module.patch()
            response_results(response, print_json_rows=False)
            assert response.json()[0]['id'] == get_id_racks, f"ID from response does not match expected ID {get_id_racks}."
            assert response.json()[0]['name'] == get_name, f"Name from response does not match expected Name{get_name}."

    @pytest.mark.parametrize('test_data', ['test_patch_update_racks_id'], indirect=True)
    def test_patch_update_racks_id(self, http, test_data, response_results, response_asserts,
                                       response_assert_fields, get_object_id, apikey, get_object_data):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_racks)
            module.set_headers(header)
            get_id_racks = get_object_id(module)
            get_name = get_object_data(module, "name")
            get_status = get_object_data(module, "status")
            get_location = get_object_data(module, "location")
            id_location = get_location['id']
            module = http(end_point)
            payload = {
                "name": get_name,
                "location": id_location,
                "status": get_status,
                "comments": row['comments']
            }
            module.set_headers(header)
            module.set_body(payload)
            response = module.patch(get_id_racks)
            response_results(response, print_json_rows=False)
            response_asserts(response)
            response_assert_fields(response, payload)
            assert response.json()['name'] == get_name, f"Name from response does not match expected Name {get_name}."
            assert response.json()['id'] == get_id_racks, f"ID from response does not match expected ID{get_id_racks}."

    @pytest.mark.parametrize('test_data', ['test_delete_racks'], indirect=True)
    def test_delete_racks(self, http, test_data, response_results, response_asserts,
                              response_assert_fields, apikey, get_object_id, get_object_data):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        id_location = self.get_object_id(http, apikey, self.url_locations + '{}',
                                         "name=QA-TD Location - view")
        for row in test_data['data']:
            header = {"Authorization": f'{apikey}'}
            module = http(self.url_status)
            module.set_headers(header)
            id_status = get_object_data(module, "id")
            object_id = self.create_entry_for_testing(http, row, id_status, '/api/dcim/racks/', id_location, apikey=apikey)
            end_point = row['ENDPOINT']
            module = http(end_point)
            module.set_headers(header)
            response = module.delete(object_id)
            response_results(response, print_json=False, print_content_type=False)
            response_asserts(response, status_code=204, assert_json=False, assert_content_type=False)

            get_end_point = '/api/dcim/racks/{}/'.format(object_id)
            module = http(get_end_point)
            module.set_headers(header)
            response = module.get(object_id)
            assert response.status_code == 404, "The status code not is equal at 404"
            assert response.json()['detail'] == 'No Rack matches the given query.', "The Request wasn't deleted."
