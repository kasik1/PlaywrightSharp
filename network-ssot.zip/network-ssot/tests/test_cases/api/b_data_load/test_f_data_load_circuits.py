import pytest


@pytest.mark.data_load
class TestCircuits:

    def setup(self):
        self.url_provider = '/api/circuits/providers/'
        self.url_circuit_type = '/api/circuits/circuit-types/'

    @staticmethod
    def update_record(module, payload, object_id, response_results, response_asserts):
        module.set_body(payload)
        response = module.put(object_id + '/')
        response_results(response, print_json_rows=False)
        response_asserts(response)
        return response

    @staticmethod
    def create_record(module, payload, response_results, response_asserts):
        module.set_body(payload)
        response = module.post('')
        response_results(response, print_json_rows=False)
        response_asserts(response, status_code=201)
        return response

    @staticmethod
    def set_payload_provider(name, slug):
        payload = {
            'comments': 'Created by Load Test Data Script',
            'slug': slug,
            'name': name
        }
        return payload

    @staticmethod
    def set_payload_circuit_type(name, slug):
        payload = {
            'comments': 'Created by Load Test Data Script',
            'slug': slug,
            'name': name
        }
        return payload

    @staticmethod
    def set_payload_circuit(provider, circuit_type, cid):
        payload = {
            'comments': 'Created by Load Test Data Script',
            'status': 'Active',
            'provider': provider,
            'circuit_type': circuit_type,
            'cid': cid
        }
        return payload

    @staticmethod
    def get_pbject_id(http, response_results, apikey, end_point, search):
        header = {"Authorization": f'{apikey}'}
        module = http(end_point)
        module.set_headers(header)
        response = module.get(f"?{search}")
        response_results(response)
        assert 'results' in response.json(), "the result not is  successful with the filter"
        id = response.json()['results'][0]['id']
        return id

    @pytest.mark.parametrize('test_data', ['test_data_load_providers'], indirect=True)
    def test_data_load_providers(self, http, test_data, response_results, apikey, response_asserts,
                                 response_assert_fields):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the csv file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        header = {"Authorization": f'{apikey}'}
        providers = [
            {'name': 'Test-Provider-01'},
            {'name': 'Test-Provider-02'}]

        for row in test_data['data']:
            end_point = row['ENDPOINT']
            module = http(end_point)
            module.set_headers(header)

            for provider in providers:
                name = provider['name']
                slug = provider['name'].lower()
                payload = self.set_payload_provider(name, slug)
                response = module.get(f"?name={name}")
                response_results(response)

                if response.json()['results']:
                    object_id = response.json()['results'][0]['id']
                    self.update_record(module, payload, object_id, response_results, response_asserts)

                else:
                    self.create_record(module, payload, response_results, response_asserts)

    @pytest.mark.parametrize('test_data', ['test_data_load_circuit_type'], indirect=True)
    def test_data_load_circuit_type(self, http, test_data, response_results, apikey, response_asserts,
                                    response_assert_fields):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the csv file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        header = {"Authorization": f'{apikey}'}

        for row in test_data['data']:
            end_point = row['ENDPOINT']
            module = http(end_point)
            module.set_headers(header)

            for num in range(1, 4):
                name = f'Test-Circuit-Type 0{num}'
                slug = f'test-circuit-type-0{num}'
                payload = self.set_payload_circuit_type(name, slug)
                response = module.get(f"?name={name}")
                response_results(response)

                if response.json()['results']:
                    object_id = response.json()['results'][0]['id']
                    self.update_record(module, payload, object_id, response_results, response_asserts)

                else:
                    self.create_record(module, payload, response_results, response_asserts)

    @pytest.mark.parametrize('test_data', ['test_data_load_circuits'], indirect=True)
    def test_data_load_circuits(self, http, test_data, response_results, apikey, response_asserts,
                                response_assert_fields):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the csv file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        header = {"Authorization": f'{apikey}'}
        provider = self.get_pbject_id(http, response_results, apikey, self.url_provider+'{}', "name=Test-Provider-01")
        circuit_type = self.get_pbject_id(http, response_results, apikey, self.url_circuit_type+'{}',
                                          "name=Test-Circuit-Type 01")
        circuits = [
            {'name': 'Test-Circuit 01'},
            {'name': 'Test-Circuit 02'}]
        
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            module = http(end_point)
            module.set_headers(header)

            for circuit in circuits:
                cid = circuit['name']

                payload = self.set_payload_circuit(provider, circuit_type, cid)
                response = module.get(f"?cid={cid}")
                response_results(response)

                if response.json()['results']:
                    object_id = response.json()['results'][0]['id']
                    self.update_record(module, payload, object_id, response_results, response_asserts)

                else:
                    self.create_record(module, payload, response_results, response_asserts)
