import pytest


@pytest.mark.data_load
class TestLocations:

    @staticmethod
    def set_location_type_payload(name, content_types, slug):
        payload = {
            "name": name,
            'description': 'Created by Load Test Data Script',
            'content_types': content_types,
            'slug': slug,
            'nestable': True
        }
        return payload

    @staticmethod
    def set_location_payload(name, status, slug):
        payload = {
            "name": name,
            'description': 'Created by Load Test Data Script',
            'location_type': 'QA-TD Location Type - view',
            'status': status,
            'slug': slug,
        }
        return payload

    @staticmethod
    def update_record(module, payload, object_id):
        module.set_body(payload)
        response = module.put(object_id + '/')
        return response

    @staticmethod
    def create_record(module, payload):
        module.set_body(payload)
        response = module.post('')
        return response

    @pytest.mark.parametrize('test_data', ['test_data_load_location_type'], indirect=True)
    def test_data_load_location_type(self, http, test_data, response_results, apikey, response_asserts,
                                     response_assert_fields):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the csv file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        names = ['view', 'update', 'delete']
        header = {"Authorization": f'{apikey}'}
        content_types = [
                'dcim.device',
                'dcim.rack',
                'ipam.prefix',
                'ipam.vlan',
                'circuits.circuittermination',
                'dcim.powerpanel',
                'dcim.rackgroup',
                'ipam.vlangroup',
                'ipam.namespace',
                'virtualization.cluster'
            ]

        for row in test_data['data']:
            end_point = row['ENDPOINT']
            module = http(end_point)
            module.set_headers(header)

            for name in names:
                slug = f'qa-td-location-type-{name}'
                name = f'QA-TD Location Type - {name}'
                payload = self.set_location_type_payload(name, content_types, slug)
                response = module.get(f"?name={name}")
                response_results(response)

                if response.json()['results']:
                    object_id = response.json()['results'][0]['id']
                    response = self.update_record(module, payload, object_id)
                    response_results(response, print_json_rows=False)
                    response_asserts(response)

                else:
                    response = self.create_record(module, payload)
                    response_results(response, print_json_rows=False)
                    response_asserts(response, status_code=201)

    @pytest.mark.parametrize('test_data', ['test_data_load_location'], indirect=True)
    def test_data_load_location(self, http, test_data, response_results, apikey, response_asserts,
                                response_assert_fields):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the csv file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        names = ['QA-TD Location - view', 'QA-TD Location - update', 'QA-TD Location - delete', 'ADC']
        slug = ['qa-td-location-view', 'qa-td-location-update', 'qa-td-location-delete']

        header = {"Authorization": f'{apikey}'}

        for row in test_data['data']:
            end_point = row['ENDPOINT']
            module = http(end_point)
            module.set_headers(header)

            for name in names:
                slug = f'{slug}'
                name = f'{name}'
                status = 'Active'
                payload = self.set_location_payload(name, status, slug)
                response = module.get(f"?name={name}")
                response_results(response)
                if name == 'ADC':
                    if response.json()['results']:
                        object_id = response.json()['results'][0]['id']
                        print(object_id)
                    else:
                        payload = {
                            "name": name,
                            'description': 'Created by Load Test Data Script',
                            'location_type': 'Site',
                            'status': 'Decommissioning',
                            'slug': slug,
                            'custom_fields':{
                                'site_code_full': 'USAVABC000',
                                'system_of_record': 'IPFabric',
                                'last_synced_from_sor': '2024-07-18',
                                'site_code' : 'None',
                                'snow_sys_id': 'None'
                            }
                        }
                        response = self.create_record(module, payload)
                        response_results(response, print_json_rows=False)
                        response_asserts(response, status_code=201)
                else:
                    if response.json()['results']:
                        object_id = response.json()['results'][0]['id']
                        response = self.update_record(module, payload, object_id)
                        response_results(response, print_json_rows=False)
                        response_asserts(response)
                    else:
                        response = self.create_record(module, payload)
                        response_results(response, print_json_rows=False)
                        response_asserts(response, status_code=201)

