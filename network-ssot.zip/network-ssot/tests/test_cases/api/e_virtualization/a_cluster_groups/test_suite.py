import pytest


@pytest.mark.smoke
class TestClusterGroupsSmokeTesting:
    @pytest.mark.parametrize('test_data', ['test_get_cluster_groups'], indirect=True)
    def test_get_cluster_groups(self, http, test_data, response_results, response_asserts, response_assert_fields, apikey):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        response_fields = ['results']
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(end_point)
            module.set_headers(header)
            response = module.get()
            response_results(response)
            response_asserts(response)
            response_assert_fields(response, response_fields)


@pytest.mark.parallel
@pytest.mark.functional
class TestClusterGroups:

    def setup(self):
        self.url_cluster_groups = '/api/virtualization/cluster-groups/'

    @staticmethod
    def create_entry_for_testing(http, row, end_point, apikey, return_id=True):
        """ This method creates the payload to be sent in the rquest of the following test cases,
                Payload : is the set of data that will be sent to generate the intake ticket
                Module : contains the instruction for the execution of the method to be carried out, example: post (), get () etc.
                Response : contains the response after the post was executed, or get
                Create an if : this looks for the id tag in the respons to check that the pyload was generated correctly"""
        module = http(end_point)
        header = {"Authorization": f'{apikey}',
                  'Content-type': 'application/json'}
        payload = {
                "name": row['name'],
                "natural_slug": row['slug']
        }
        module.set_headers(header)
        module.set_body(payload)
        response = module.post()
        if return_id:
            assert 'id' in response.json(), "New Automation Request entry for testing was not created successfully."
            return response.json()['id']

    @pytest.mark.parametrize('test_data', ['test_get_cluster_groups_id'], indirect=True)
    def test_get_cluster_groups_id(self, http, test_data, response_results, response_asserts, response_assert_fields, apikey, get_object_id):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        response_fields = ['id', 'name', 'description', 'url', 'natural_slug']
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_cluster_groups)
            module.set_headers(header)
            response = module.get()
            if not response.json()['results']:
                self.create_entry_for_testing(http, row, '/api/virtualization/cluster-groups/',
                                                          apikey=apikey)
            get_id_cluster = get_object_id(module)
            module = http(end_point)
            module.set_headers(header)
            response = module.get(get_id_cluster)
            response_results(response, print_json_rows=False)
            response_asserts(response)
            response_assert_fields(response, response_fields)

    @pytest.mark.parametrize('test_data', ['test_post_create_cluster_groups'], indirect=True)
    def test_post_create_cluster_groups(self, http, test_data, response_results, apikey, response_asserts,
                                            response_assert_fields):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            module = http(end_point)
            header = {"Authorization": f'{apikey}',
                'Content-type': 'application/json'}
            payload = {
                   "name": row['name'],
                   "natural_slug": row['slug'],
            }
            module.set_body(payload)
            module.set_headers(header)
            response = module.post()
            response_results(response, print_json_rows=False)
            response_asserts(response, status_code=201)
            response_assert_fields(response, payload)
            object_id = response.json()['id']
            get_end_point = '/api/virtualization/cluster-groups/{}/'.format(object_id)
            module = http(get_end_point)
            module.set_headers(header)
            response = module.delete(object_id)
            response_results(response, print_json=False, print_content_type=False)
            response_asserts(response, status_code=204, assert_json=False, assert_content_type=False)

    @pytest.mark.parametrize('test_data', ['test_put_update_cluster_groups'], indirect=True)
    def test_put_update_cluster_groups(self, http, test_data, response_results, get_object_id, apikey, get_object_data):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_results: Fixture that will print information about the Test
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_cluster_groups)
            module.set_headers(header)
            get_id_cluster = get_object_id(module)
            get_name = get_object_data(module, "name")
            get_slug = get_object_data(module, "natural_slug")
            module = http(end_point)
            payload = [{
                "id": get_id_cluster,
                "name": get_name,
                "natural_slug": get_slug}]
            module.set_headers(header)
            module.set_body(payload)
            response = module.put()
            print(response.json())
            response_results(response, print_json_rows=False)
            assert response.json()[0]['id'] == get_id_cluster, f"ID from response does not match expected ID {get_id_cluster}."
            assert response.json()[0]['name'] == get_name, f"Name from response does not match expected Name {get_name}."

    @pytest.mark.parametrize('test_data', ['test_put_update_cluster_groups_id'], indirect=True)
    def test_put_update_cluster_groups_id(self, http, test_data, response_results, response_asserts,
                                           response_assert_fields, get_object_id, apikey, get_object_data):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_cluster_groups)
            module.set_headers(header)
            get_id_cluster = get_object_id(module)
            get_name = get_object_data(module, "name")
            get_slug = get_object_data(module, "natural_slug")
            module = http(end_point)
            payload = {
                "name": get_name,
                "natural_slug": get_slug}
            module.set_headers(header)
            module.set_body(payload)
            response = module.put(get_id_cluster)
            response_results(response, print_json_rows=False)
            response_asserts(response)
            response_assert_fields(response, payload)
            assert response.json()['name'] == get_name, f"Name from response does not match expected Name {get_name}."
            assert response.json()['natural_slug'] == get_slug, f"Slug from response does not match expected Slug {get_slug}."

    @pytest.mark.parametrize('test_data', ['test_patch_update_cluster_groups'], indirect=True)
    def test_patch_update_cluster_groups(self, http, test_data, response_results, get_object_id, get_object_data, apikey):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_results: Fixture that will print information about the Test
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_cluster_groups)
            module.set_headers(header)
            get_id_cluster = get_object_id(module)
            get_name = get_object_data(module, "name")
            get_slug = get_object_data(module, "natural_slug")
            module = http(end_point)
            payload = [{
                "id": get_id_cluster,
                "name": get_name,
                "natural_slug": get_slug}]
            module.set_headers(header)
            module.set_body(payload)
            response = module.patch()
            response_results(response, print_json_rows=False)
            assert response.json()[0]['id'] == get_id_cluster, f"ID from response does not match expected ID {get_id_cluster}."
            assert response.json()[0]['name'] == get_name, f"Name from response does not match expected Name {get_name}."

    @pytest.mark.parametrize('test_data', ['test_patch_update_cluster_groups_id'], indirect=True)
    def test_patch_update_cluster_groups_id(self, http, test_data, response_results, response_asserts,
                                   response_assert_fields, get_object_id, apikey, get_object_data):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            end_point = row['ENDPOINT']
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.url_cluster_groups)
            module.set_headers(header)
            get_id_cluster = get_object_id(module)
            get_name = get_object_data(module, "name")
            get_slug = get_object_data(module, "natural_slug")
            module = http(end_point)
            payload = {
                "name": get_name,
                "natural_slug": get_slug,}
            module.set_headers(header)
            module.set_body(payload)
            response = module.patch(get_id_cluster)
            response_results(response, print_json_rows=False)
            response_asserts(response)
            response_assert_fields(response, payload)
            assert response.json()['name'] == get_name, f"Name from response does not match expected Name {get_name}."
            assert response.json()['natural_slug'] == get_slug, f"Slug from response does not match expected Slug {get_slug}."

    @pytest.mark.parametrize('test_data', ['test_delete_cluster_groups'], indirect=True)
    def test_delete_cluster_groups(self, http, test_data, response_results, response_asserts,
                                       response_assert_fields,apikey):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the excel file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        :param response_assert_fields: Fixture that will assert fields to be present in te response
        """
        for row in test_data['data']:
            header = {"Authorization": f'{apikey}'}
            object_id = self.create_entry_for_testing(http, row, '/api/virtualization/cluster-groups/', apikey=apikey)
            end_point = row['ENDPOINT']
            module = http(end_point)
            module.set_headers(header)
            response = module.delete(object_id)
            response_results(response, print_json=False, print_content_type=False)
            response_asserts(response, status_code=204, assert_json=False, assert_content_type=False)

            get_end_point = '/api/virtualization/cluster-groups/{}/'.format(object_id)
            module = http(get_end_point)
            module.set_headers(header)
            response = module.get(object_id)
            assert response.status_code == 404, "The status code not is equal at 404"
            assert response.json()['detail'] == 'No ClusterGroup matches the given query.', "The Request wasn't deleted."
