"""
This files includes configuration and methods for pytest to execute them as hooks
"""
from tests.endpoints.tenancy import Tenancy as Module
from tests.commons.functions import fill_test_case_detail_values
from tests.commons.csv import Csv
import pytest
import os


@pytest.fixture(scope='session')
def spreadsheet():
    path = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(path, 'test_data.csv')
    return Csv(file_path)


@pytest.fixture()
def setup_server_url(spreadsheet, testing_environment):
    return testing_environment(spreadsheet)


@pytest.fixture()
def test_data(request, spreadsheet):
    fixture_name = request.param
    data = {
        'test_case': {
            'test_case_id': '',
            'build': '',
            'tester': '',
            'notes': '',
            'c_environment': ''},
        'data': []}

# If fixture 'user_session' is being used
    if 'user_session' in request.keywords.node.funcargs:
        cookie = getattr(request.keywords.node.funcargs['user_session'], 'cookies', False)
        user_group = {'user_group': cookie['user_group']}
    else:
        user_group = {'user_group': []}
    data['test_case'].update(user_group)

    for row in (row for row in spreadsheet.rows() if row['TEST_TYPE'] == fixture_name):
        data = fill_test_case_detail_values(data, row)
        data['data'].append(row)
    return data


@pytest.fixture
def http(session, setup_server_url):
    def _module(end_point, user_session=False):
        aux_session = session()
        if user_session:
            aux_session = user_session
        return Module(aux_session, setup_server_url, endpoint=end_point)
    return _module
