import pytest


class Extras:
    def setup(self):
        self.end_point = '/api/extras/custom-fields/'

    @staticmethod
    def set_payload(row):
        payload = {
            'content_types': [row['content_types']],
            'name': row['name'],
            'type': row['type'],
            'label': row['label'],
            'description': row['description']}
        return payload


@pytest.mark.smoke
class TestCustomFieldsSmokeTesting(Extras):
    """
    Smoke Testing
    """
    @pytest.mark.parametrize('test_data', ['test_get_custom_fields'], indirect=True)
    def test_get_custom_fields(self, http, test_data, response_results, response_asserts, apikey):
        """
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the csv file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        """
        header = {
            "Authorization": f'{apikey}'}
        module = http(self.end_point)
        module.set_headers(header)
        response = module.get()
        response_results(response)
        response_asserts(response)


@pytest.mark.parallel
@pytest.mark.functional
class TestCustomFieldsIT(Extras):
    """
    Integration Testing
    """
    def create_entry_for_testing(self, http, row, apikey, return_id=True):
        """ This method creates the payload to be sent in the request of the following test cases,
        :param http: Endpoint Class which contains requests methods
        :param row: Test Data Row from the csv file
        :param apikey: Token to get access to the endpoints
        :param return_id: Boolean variable to return or not the created id
        """
        module = http(self.end_point)
        header = {"Authorization": f'{apikey}',
                  'Content-type': 'application/json'}
        payload = self.set_payload(row)
        module.set_headers(header)
        module.set_body(payload)
        response = module.post()
        if return_id:
            assert 'id' in response.json(), 'New Record for testing was not created successfully'
            return response.json()['id']

    def delete_method(self, http, object_id, apikey):
        headers = {"Authorization": f'{apikey}'}
        module = http(self.end_point + f'{object_id}/')
        module.set_headers(headers)
        response = module.delete()
        assert response.status_code == 204

    @pytest.mark.parametrize('test_data', ['test_post_custom_field'], indirect=True)
    def test_post_custom_field(self, http, test_data, response_results, response_asserts, apikey):
        """
        Post Custom Field
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the csv file
        :param response_asserts: Fixture that will assert the response with its validations
        :param response_results: Fixture that will print information about the Test
        """
        for row in test_data['data']:
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.end_point)
            payload = self.set_payload(row)
            module.set_headers(header)
            module.set_body(payload)
            response = module.post()
            response_results(response, print_json_rows=False)
            response_asserts(response, status_code=201)
            created_id = response.json()['id']
            self.delete_method(http, created_id, apikey)

    @pytest.mark.parametrize('test_data', ['test_put_custom_fields'], indirect=True)
    def test_put_custom_fields(self, http, test_data, response_results, apikey, response_asserts):
        """
        Bulk Update Custom Fields
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the csv file
        :param response_results: Fixture that will print information about the Test
        """
        for row in test_data['data']:
            created_id = self.create_entry_for_testing(http, row, apikey)
            print(created_id)
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.end_point)
            module.set_headers(header)
            obj_payload = {**self.set_payload(row), **{'id': created_id}}
            payload = [obj_payload]
            module.set_body(payload)
            response = module.put()
            response_results(response, print_json_rows=False)
            response_asserts(response)
            self.delete_method(http, created_id, apikey)

    @pytest.mark.parametrize('test_data', ['test_patch_custom_fields'], indirect=True)
    def test_patch_custom_fields(self, http, test_data, response_results, apikey, response_asserts):
        """
        Bulk Partial Update Custom Fields
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the csv file
        :param response_results: Fixture that will print information about the Test
        """
        for row in test_data['data']:
            created_id = self.create_entry_for_testing(http, row, apikey)
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.end_point)
            module.set_headers(header)
            obj_payload = {**self.set_payload(row), **{'id': created_id}}
            payload = [obj_payload]
            module.set_body(payload)
            response = module.patch()
            response_results(response, print_json_rows=False)
            response_asserts(response)
            self.delete_method(http, created_id, apikey)

    @pytest.mark.parametrize('test_data', ['test_delete_custom_fields'], indirect=True)
    def test_delete_custom_fields(self, http, test_data, response_results, apikey, response_asserts):
        """
        Bulk Delete Custom Fields
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the csv file
        :param response_results: Fixture that will print information about the Test
        """
        for row in test_data['data']:
            created_id = self.create_entry_for_testing(http, row, apikey)
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.end_point)
            module.set_headers(header)
            payload = [{'id': created_id}]
            module.set_body(payload)
            response = module.delete()
            response_results(response, print_json=False, print_content_type=False)
            response_asserts(response, status_code=204, assert_content_type=False, assert_json=False)

    @pytest.mark.parametrize('test_data', ['test_get_single_custom_field'], indirect=True)
    def test_get_single_custom_field(self, http, test_data, response_results, apikey, response_asserts):
        """
        Get single Custom Fields
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the csv file
        :param response_results: Fixture that will print information about the Test
        """
        for row in test_data['data']:
            created_id = self.create_entry_for_testing(http, row, apikey)
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.end_point + f'{created_id}/')
            module.set_headers(header)
            response = module.get()
            response_results(response, print_json_rows=False)
            response_asserts(response)
            self.delete_method(http, created_id, apikey)

    @pytest.mark.parametrize('test_data', ['test_put_single_custom_field'], indirect=True)
    def test_put_single_custom_field(self, http, test_data, response_results, apikey, response_asserts):
        """
        Update Put single Custom Fields
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the csv file
        :param response_results: Fixture that will print information about the Test
        """
        for row in test_data['data']:
            created_id = self.create_entry_for_testing(http, row, apikey)
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.end_point + f'{created_id}/')
            module.set_headers(header)
            payload = {**self.set_payload(row), **{'id': created_id}}
            module.set_body(payload)
            response = module.put()
            response_results(response, print_json_rows=False)
            response_asserts(response)
            self.delete_method(http, created_id, apikey)

    @pytest.mark.parametrize('test_data', ['test_patch_single_custom_field'], indirect=True)
    def test_patch_single_custom_field(self, http, test_data, response_results, apikey, response_asserts):
        """
        Update Patch single Custom Fields
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the csv file
        :param response_results: Fixture that will print information about the Test
        """
        for row in test_data['data']:
            created_id = self.create_entry_for_testing(http, row, apikey)
            header = {
                "Authorization": f'{apikey}'}
            module = http(self.end_point + f'{created_id}/')
            module.set_headers(header)
            payload = {**self.set_payload(row), **{'id': created_id}}
            module.set_body(payload)
            response = module.patch()
            response_results(response, print_json_rows=False)
            response_asserts(response)
            self.delete_method(http, created_id, apikey)

    @pytest.mark.parametrize('test_data', ['test_delete_single_custom_field'], indirect=True)
    def test_delete_single_custom_field(self, http, test_data, response_results, apikey, response_asserts):
        """
        Delete single Custom Fields
        :param http: Endpoint Class which contains requests methods
        :param test_data: Test Data from the csv file
        :param response_results: Fixture that will print information about the Test
        """
        for row in test_data['data']:
            created_id = self.create_entry_for_testing(http, row, apikey)
            self.delete_method(http, created_id, apikey)
