import pytest


class SNOW:
    def setup(self):
        self.UPDATE = "Updated 2 devices"
        self.production = "Devices have been moved to Production"
        self.preprod = "Devices have been moved to Pre-production"


@pytest.mark.smoke
class TestBulkServiceNowSmoke(SNOW):

    @pytest.mark.parametrize('test_data', ['test_show_module'], indirect=True)
    def test_show_module(self, ssot, test_data, setup_server_url):
        ssot.bulk_snow_page()
        assert ssot.is_title_present('ServiceNow Bulk Devices', type='h1', timeout=60)

    @pytest.mark.parametrize('test_data', ['test_show_move_prod_button'], indirect=True)
    def test_show_move_prod_button(self, ssot, test_data, setup_server_url):
        ssot.bulk_snow_page()
        assert ssot.show_production_button()

    @pytest.mark.parametrize('test_data', ['test_show_move_preprod_button'], indirect=True)
    def test_show_move_preprod_button(self, ssot, test_data):
        ssot.bulk_snow_page()
        assert ssot.show_preprod_button()


@pytest.mark.functional
class TestBulkServiceNow(SNOW):
    """Class for the devices module in ssot"""

    @pytest.mark.parametrize('test_data', ['test_button_ci'], indirect=True)
    def test_button_ci(self, ssot, test_data, setup_server_url):
        """ service now - testing the send button and validate that the requests change to send"""
        for row in test_data['data']:
            ssot.home_page(setup_server_url)
            ssot.bulk_snow_page()
            ssot.search_device(row['NAME'])
            names = ssot.checkbox_multi()
            ssot.button_ci()
            assert ssot.is_title_present('Service Now Device Requests', type='h1', timeout=60)
            for name in names:
                ssot.check_request(name, "Add")

    @pytest.mark.parametrize('test_data', ['test_button_edit_bulk'], indirect=True)
    def test_button_edit_bulk(self, ssot, test_data, setup_server_url):
        """ service now - testing the send button and validate that the requests change to send"""
        for row in test_data['data']:
            ssot.home_page(setup_server_url)
            ssot.bulk_snow_page()
            ssot.search_device(row['NAME'])
            ssot.checkbox_multi()
            ssot.button_edit()
            ssot.edit_data(data=row)
            assert ssot.check_alert_text(self.UPDATE), f"The alert text is not {self.UPDATE} as we expected."

    @pytest.mark.parametrize('test_data', ['test_button_decom_bulk'], indirect=True)
    def test_button_decom_bulk(self, ssot, test_data, setup_server_url):
        """ service now - testing the send button and validate that the requests change to send"""
        for row in test_data['data']:
            ssot.home_page(setup_server_url)
            ssot.bulk_snow_page()
            ssot.search_device(row['NAME'])
            names = ssot.checkbox_multi()
            ssot.button_decom()
            assert ssot.is_title_present('Service Now Device Requests', type='h1', timeout=60)
            for name in names:
                ssot.check_request(name, "Decom")

    @pytest.mark.parametrize('test_data', ['test_move_production_button'], indirect=True)
    def test_move_production_button(self, ssot, test_data, setup_server_url):
        """ service now - testing the send button and validate that the requests change to send"""
        for row in test_data['data']:
            ssot.bulk_snow_page()
            ssot.search_device(row['NAME'])
            ssot.check_element()
            ssot.production_button()
            assert ssot.check_alert_text(self.production), f"The alert text is not {self.production} as we expected."
            ssot.search_device(row['NAME'])
            assert ssot.check_status(row['NAME']) == "Production"

    @pytest.mark.parametrize('test_data', ['test_move_preproduction_button'], indirect=True)
    def test_move_preproduction_button(self, ssot, test_data, setup_server_url):
        """ service now - testing the send button and validate that the requests change to send"""
        for row in test_data['data']:
            ssot.bulk_snow_page()
            ssot.search_device(row['NAME'])
            ssot.check_element()
            ssot.preprod_button()
            assert ssot.check_alert_text(self.preprod), f"The alert text is not {self.preprod} as we expected."
            ssot.search_device(row['NAME'])
            assert ssot.check_status(row['NAME']) == "Pre-production"


