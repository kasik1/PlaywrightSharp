import os
import pytest
from datetime import datetime


class DeviceBulk:
    def setup(self):
        self.imported = "Imported 2 devices"
        self.delete = "Deleted device"
        self.url = "/plugins/ssot-cigna/custom_device_bulk_import/"
        self.production = "Imported 4 devices"


@pytest.mark.smoke
class TestDeviceBulkSmoke(DeviceBulk):

    @pytest.mark.parametrize('test_data', ['test_show_module'], indirect=True)
    def test_show_module(self, ssot, test_data, setup_server_url):
        ssot.device_bulk()
        assert ssot.is_title_present('Device Bulk Import', type='h1', timeout=60)

    @pytest.mark.parametrize('test_data', ['test_show_csv_data'], indirect=True)
    def test_show_csv_data(self, ssot, test_data, setup_server_url):
        ssot.device_bulk()
        assert ssot.check_csv_data()

    @pytest.mark.parametrize('test_data', ['test_show_csv_file'], indirect=True)
    def test_show_csv_file(self, ssot, test_data):
        ssot.device_bulk()
        assert ssot.check_csv_file()


@pytest.mark.functional
class TestDeviceBulk(DeviceBulk):
    """Class for the devices module in ssot"""

    @pytest.mark.parametrize('test_data', ['test_device_bulk'], indirect=True)
    def test_device_bulk(self, ssot, test_data, setup_server_url):
        """ service now - testing the send button and validate that the requests change to send"""
        for row in test_data['data']:
            names = ["device_bulk_test1", "device_bulk_test2"]
            ssot.home_page(setup_server_url)
            ssot.device_bulk()
            ssot.insert_data_text(row['Data_CSV'])
            ssot.click_submit_button()
            assert ssot.check_alert_text(self.imported), f"The alert text is not {self.imported} as we expected."
            for name in names:
                found_contact = ssot.search_device(name)
                assert found_contact, f"No contact with name {name} found."
                ssot.delete_device(name)
                assert ssot.check_alert_text(
                    self.delete), f"The alert text is not {self.delete} as we expected."

    @pytest.mark.parametrize('test_data', ['test_device_bulk_false'], indirect=True)
    def test_device_bulk_false(self, ssot, test_data, setup_server_url):
        """ service now - testing the send button and validate that the requests change to send"""
        for row in test_data['data']:
            ssot.home_page(setup_server_url)
            ssot.device_bulk()
            ssot.insert_data_text(row['Data_CSV'])
            ssot.click_submit_button()
            assert ssot.check_url(self.url)

    @pytest.mark.parametrize('test_data', ['test_file_bulk'], indirect=True)
    def test_file_bulk(self, ssot, test_data, setup_server_url):
        """ service now - testing the send button and validate that the requests change to send"""
        for row in test_data['data']:
            names = ["test_bulke_file1", "test_bulke_file2"]
            ssot.home_page(setup_server_url)
            ssot.device_bulk()
            ssot.check_csv_file()
            path = os.path.dirname(os.path.abspath(__file__))
            select_file = os.path.join(path, 'devices.csv')
            ssot.add_csv_file(select_file)
            ssot.submit_csv()
            assert ssot.check_alert_text(self.imported), f"The alert text is not {self.imported} as we expected."
            for name in names:
                found_contact = ssot.search_device(name)
                assert found_contact, f"No contact with name {name} found."
                ssot.delete_device(name)
                assert ssot.check_alert_text(
                    self.delete), f"The alert text is not {self.delete} as we expected."

    @pytest.mark.parametrize('test_data', ['test_file_bulk_false'], indirect=True)
    def test_file_bulk_false(self, ssot, test_data, setup_server_url):
        """ service now - testing the send button and validate that the requests change to send"""
        for row in test_data['data']:
            ssot.home_page(setup_server_url)
            ssot.device_bulk()
            ssot.check_csv_file()
            path = os.path.dirname(os.path.abspath(__file__))
            select_file = os.path.join(path, 'devices_missing.csv')
            ssot.add_csv_file(select_file)
            ssot.submit_csv()
            assert ssot.check_url(self.url)

    @pytest.mark.parametrize('test_data', ['test_devices_get_unclaimed_status_date'], indirect=True)
    def test_devices_get_unclaimed_status_date(self, ssot, test_data, setup_server_url):
        """ validate that  a device created with unclaimed  status get unclaimed date"""
        ssot.home_page(setup_server_url)
        ssot.device_bulk()
        ssot.check_csv_file()
        path = os.path.dirname(os.path.abspath(__file__))
        select_file = os.path.join(path, 'devices_unclaimed.csv')
        names = ssot.get_data_from_csv(select_file)
        ssot.add_csv_file(select_file)
        ssot.submit_csv()
        assert ssot.check_alert_text(self.imported), f"The alert text is not {self.imported} as we expected."
        for name in names:
            found_contact = ssot.search_device(name)
            assert found_contact, f"No contact with name {name} found."
            ssot.click_link_text(name)
            assert ssot.get_device_status() == "Unclaimed"
            assert ssot.get_device_unclaimed_date() == datetime.now().strftime('%Y-%m-%d'), \
                "Expected today's date as unclaimed date"
            ssot.delete_unclaimed_device(name)
            assert ssot.check_alert_text(self.delete), f"The alert text is not " \
                                                       f"{self.delete} as we expected"

    @pytest.mark.parametrize('test_data', ['test_devices_not_update_unclaimed_date'], indirect=True)
    def test_devices_not_update_unclaimed_date(self, ssot, test_data, setup_server_url):
        """ validate that  a devices created with  production status data, should not  contain unclaimed  status
        should not get unclaimed date"""
        ssot.home_page(setup_server_url)
        ssot.device_bulk()
        ssot.check_csv_file()
        path = os.path.dirname(os.path.abspath(__file__))
        select_file = os.path.join(path, 'devices_bulk.csv')
        ssot.add_csv_file(select_file)
        names = ssot.get_data_from_csv(select_file)
        ssot.submit_csv()
        assert ssot.check_alert_text(self.production), f"The alert text is not {self.production} as we expected."
        for name in names:
            found_contact = ssot.search_device(name)
            assert found_contact, f"No contact with name {name} found."
            ssot.click_link_text(name)
            assert ssot.get_device_status() != 'Unclaimed'
            assert ssot.get_device_unclaimed_date != "Device unclaimed date should not be unclaimed"
            ssot.delete_unclaimed_device(name)
            assert ssot.check_alert_text(self.delete), f"The alert text is not " \
                                                       f"{self.delete} as we expected"
