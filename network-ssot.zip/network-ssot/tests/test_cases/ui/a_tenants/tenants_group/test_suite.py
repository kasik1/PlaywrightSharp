import os
from tests.fixtures.users import create_login
import pytest


class TenantsGroup:

    def setup(self):
        self.ADD_OK = "Created tenant group"
        self.UPDATE = "Modified tenant group"
        self.DELETE = "Deleted tenant group"
        self.ADD_URL = "/tenant-groups/add"


@pytest.mark.parametrize('user_session', [*create_login()])
@pytest.mark.userbase
class TestTenantGroupUserBase(TenantsGroup):

    @pytest.mark.parametrize('test_data', ['test_view_title'], indirect=True)
    def test_view_title(self, user_base, test_data, user_session, login_page):
        """ Tenant Group - Test check the title in the menu the tenants """
        title = 'Tenant Groups'
        user_base.log_out()
        login_page(user_session)
        user_base.tenant_group_page()
        assert user_base.is_title_present(title, type='h1')
        user_base.log_out()

    @pytest.mark.parametrize('test_data', ['test_add_tenants_groups'], indirect=True)
    def test_add_tenants_groups(self, user_base, test_data, user_session, login_page):
        """ Tenant Group - Add a Device Tenant Group. """
        for row in test_data['data']:
            user_base.log_out()
            login_page(user_session)
            user_base.tenant_group_page()
            user_base.click_add_button()
            user_base.set_tenant_group_data(data=row)
            user_base.log_out()

    @pytest.mark.parametrize('test_data', ['test_update_element'], indirect=True)
    def test_update_element(self, user_base, test_data, user_session,login_page):
        """ Tenants Group - Update a Tenant Group  with the required fields by model. """
        for row in test_data['data']:
            user_base.log_out()
            login_page(user_session)
            user_base.edit_tenant_groups(data=row)
            assert user_base.check_alert_text(self.UPDATE), f"The alert text is not {self.UPDATE} as we expected."
            user_base.log_out()

    @pytest.mark.parametrize('test_data', ['test_action_delete'], indirect=True)
    def test_action_delete(self, user_base, test_data, user_session, login_page):
        """ Tenant Group - Delete a Tenant Group type by model. """
        user_base.log_out()
        login_page(user_session)
        user_base.tenant_group_page()
        user_base.view_first_tenants_group()
        user_base.click_delete_button()
        user_base.log_out()


@pytest.mark.smoke
class TestTenantGroupFormValidation:

    @pytest.mark.parametrize('test_data', ['test_add_button_from_table'], indirect=True)
    def test_add_button_from_table(self, ssot, test_data):
        """ Tenant Group - Test 'Add' button from table """
        title = 'Tenant Groups'
        ssot.tenant_group_page()
        assert ssot.is_title_present(title, type='h1')


@pytest.mark.parallel
@pytest.mark.functional
class TestTenantGroup(TenantsGroup):
    """Class for the tenant group module in ssot"""

    @pytest.mark.parametrize('test_data', ['test_add_tenant_group'], indirect=True)
    def test_add_tenant_group(self, ssot, test_data):
        """ Tenant Group - Add a Device Tenant Group. """
        for row in test_data['data']:
            ssot.add_tenant_group(data=row)
            assert ssot.check_alert_text(self.ADD_OK), "The add alert is not present."

    @pytest.mark.parametrize('test_data', ['test_add_tenant_group_missing'], indirect=True)
    def test_add_tenant_group_missing(self, ssot, test_data):
        """ Tenant Group - Try to add a Device Type without the required fields. """
        for row in test_data['data']:
            ssot.add_tenant_group(data=row)
            assert ssot.check_url(self.ADD_URL), "The add alert is present."

    @pytest.mark.parametrize('test_data', ['test_view_change_log'], indirect=True)
    def test_view_change_log(self, ssot, test_data):
        """ View the change log table for a record """
        ssot.tenant_group_page()
        ssot.view_change_log_of_first_record()
        assert ssot.is_log_table_present()

    @pytest.mark.parametrize('test_data', ['test_add_tenant_group_with_parent'], indirect=True)
    def test_add_tenant_group_with_parent(self, ssot, test_data):
        """ Add a Tenant Group with a parent """
        groups_names = (row["FIRST_NAME"] for row in test_data["data"] if "PARENT" in row["FIRST_NAME"])
        for row in test_data['data']:
            ssot.add_tenant_group(data=row)
            assert ssot.alert_is_present(), "The add alert is not present."
        ssot.delete_specific_tenant_groups(groups_names)
        assert ssot.check_alert_text(self.DELETE), f"The alert text is not {self.DELETE} as we expected."

    @pytest.mark.parametrize('test_data', ['test_update_tenant_group'], indirect=True)
    def test_update_tenant_group(self, ssot, test_data):
        """ Tenants Group - Update a Tenant Group  with the required fields by model. """
        for row in test_data['data']:
            ssot.edit_tenant_groups(data=row)
            assert ssot.check_alert_text(self.UPDATE), f"The alert text is not {self.UPDATE} as we expected."

    @pytest.mark.parametrize('test_data', ['test_required_fields_edit_form'], indirect=True)
    def test_required_fields_edit_form(self, ssot, test_data):
        """ Tenants Group - test_load_data_edit in tenants with the required fields by model. """
        ssot.tenant_group_page()
        rows_name = ["Name", "Description"]
        data1, data2 = ssot.get_info_table_edit(values=rows_name)
        ssot.click_tenant()
        assert ssot.get_values_form_edit(data=[data1, data2]), "Required field values were not loaded correctly"

    @pytest.mark.parametrize('test_data', ['test_delete_tenant_group'], indirect=True)
    def test_delete_tenant_group(self, ssot, test_data):
        """ Tenant Group - Delete a Tenant Group type by model. """
        for row in test_data['data']:
            ssot.delete_tenant_groups(data=row)
            assert ssot.check_alert_text(self.DELETE), f"The alert text is not {self.DELETE} as we expected."


@pytest.mark.exports
class TestTenantsGroupExports:
    @pytest.mark.parametrize('test_data', ['test_export_tenants_group'], indirect=True)
    def test_export_tenants_group(self, ssot, test_data, rename_download):
        """ tenants group - export csv the current view. """
        ssot.tenant_group_page()
        ssot.click_export_button()
        ssot.export_current_view()

    @pytest.mark.parametrize('test_data', ['test_check_export_tenants_group'], indirect=True)
    def test_check_export_tenants_group(self, ssot, test_data, rename_download):
        """ tenants group - chek the csv in local machine"""
        ssot.tenant_group_page()
        data = ssot.get_data_for_check_export(2)
        file_name = 'tenats_group_export.csv'
        rename_download(name=file_name)
        file_path = os.path.join(os.getcwd(), file_name)
        assert os.path.isfile(file_path), "The file_path not present in root described in isfile."
        csv = ssot.read_csv(file_name)
        assert ssot. check_csv_and_data(data,csv)
        os.remove(file_path)