import os
from tests.fixtures.users import create_login
import pytest


class Circuits:
    def setup(self):
        self.ADD_OK = "Created circuit"
        self.UPDATE = "Modified circuit"
        self.DELETE = "Deleted circuit"
        self.ADD_URL = "/circuits/add/"


@pytest.mark.parametrize('user_session', [*create_login()])
@pytest.mark.userbase
class TestCircuitsUserBase(Circuits):

    @pytest.mark.parametrize('test_data', ['test_view_title_circuits'], indirect=True)
    def test_view_title_circuits(self, user_base, test_data, user_session, login_page):
        """ Circuits - Test check the title in the menu the Circuits """
        title = 'Circuits'
        user_base.log_out()
        login_page(user_session)
        user_base.circuits_page()
        assert user_base.is_title_present(title, type='h1')
        user_base.log_out()

    @pytest.mark.parametrize('test_data', ['test_add_circuits_ub'], indirect=True)
    def test_add_circuits_ub(self, user_base, test_data, user_session, login_page):
        """Circuits - Add a Circuits. """
        for row in test_data['data']:
            user_base.log_out()
            login_page(user_session)
            user_base.circuits_page()
            user_base.click_add_button()
            user_base.set_circuit_data(data=row)
            user_base.log_out()

    @pytest.mark.parametrize('test_data', ['test_update_element_circuits'], indirect=True)
    def test_update_element_circuits(self, user_base, test_data,login_page, user_session):
        """ Circuits - Update a Tenant Group  with the required fields by model. """
        for row in test_data['data']:
            user_base.log_out()
            login_page(user_session)
            found_contact = user_base.search_circuit(row['CIRCUIT_ID'])
            assert found_contact, f"No circuit with name {row['CIRCUIT_ID']} found."
            user_base.edit_circuit(row['CIRCUIT_ID'], data=row)
            assert user_base.check_alert_text(self.UPDATE), f"The alert text is not {self.UPDATE} as we expected."

    @pytest.mark.parametrize('test_data', ['test_action_delete_circuits'], indirect=True)
    def test_action_delete_circuits(self, user_base, test_data, user_session, login_page):
        """ Circuits - Delete a Tenant Group type by model. """
        user_base.log_out()
        login_page(user_session)
        user_base.circuits_page()
        user_base.view_first_record_of_table()
        user_base.click_delete_button()
        user_base.log_out()


@pytest.mark.smoke
class TestCircuitsFormValidation:

    @pytest.mark.parametrize('test_data', ['test_search_specific_circuit'], indirect=True)
    def test_search_specific_circuit(self, ssot, test_data):
        """ Circuits - Search a Circuits by name. """
        ssot.circuits_page()
        columns = ['id', 'provider', 'status']
        values = ssot.get_row_values_circuit(columns)
        found_contact = ssot.search_circuit(values['id'])
        assert found_contact, f"No contact with name {values['id']} found."
        ssot.check_specific_search_circuit(values)


@pytest.mark.functional
class TestCircuits(Circuits):
    """Class for the Circuits module in ssot"""

    @pytest.mark.parametrize('test_data', ['test_add_circuit'], indirect=True)
    def test_add_circuit(self, ssot, test_data):
        """ Circuits - Add a Circuits. """
        for row in test_data['data']:
            ssot.add_circuit(data=row)
            assert ssot.alert_is_present(), "The add alert is not present."

    @pytest.mark.parametrize('test_data', ['test_circuit_missing'], indirect=True)
    def test_circuit_missing(self, ssot, test_data):
        """ Circuits - Try to add a Circuits without the required fields. """
        for row in test_data['data']:
            ssot.add_circuit(data=row)
            assert ssot.check_url(self.ADD_URL), "The add alert is present."

    @pytest.mark.parametrize('test_data', ['test_view_circuit_details'], indirect=True)
    def test_view_circuit_details(self, ssot, test_data):
        """ Circuits - View tenant details """
        ssot.circuits_page()
        ssot.view_first_record_of_table()
        assert ssot.title_present(name="Circuit")
        ssot.are_circuit_stats_present()

    @pytest.mark.parametrize('test_data', ['test_view_change_log'], indirect=True)
    def test_view_change_log(self, ssot, test_data):
        """ View the change log table for a record """
        for row in test_data['data']:
            found_contact = ssot.search_circuit(row['CIRCUIT_ID'])
            assert found_contact, f"No contact with name {row['CIRCUIT_ID']} found."
            ssot.click_link_text(row['CIRCUIT_ID'])
            ssot.go_to_tab('Change Log')
            assert ssot.is_log_table_present()

    @pytest.mark.parametrize('test_data', ['test_update_circuit'], indirect=True)
    def test_update_circuit(self, ssot, test_data):
        """ Circuits - Update a Circuits with the required fields by model. """
        for row in test_data['data']:
            found_contact = ssot.search_circuit(row['CIRCUIT_ID'])
            assert found_contact, f"No circuit with name {row['CIRCUIT_ID']} found."
            ssot.edit_circuit(row['CIRCUIT_ID'], data=row)
            assert ssot.check_alert_text(self.UPDATE), f"The alert text is not {self.UPDATE} as we expected."

    @pytest.mark.parametrize('test_data', ['test_required_fields_edit_form'], indirect=True)
    def test_required_fields_edit_form(self, ssot, test_data):
        """ Circuits - test_load_data_edit in tenants with the required fields by model. """
        ssot.circuits_page()
        data1 = ssot.get_info_table_edit(values=["ID"])
        ssot.click_link_text(data1[0])
        rows_name = ['Provider']
        data = ssot.get_values_table_details(rows_name)+data1
        ssot.click_edit_button()
        input_values = ssot.get_input_values_form_edit(['ID'])
        select_values = ssot.get_select_values_form_edit(['Provider'])
        assert all(element in data for element in input_values+select_values), "in the edit view the required" \
                                                                     " fields were not loaded, and the " \
                                                                     "assert fails because it cannot " \
                                                                     "find the value in the form"

    @pytest.mark.parametrize('test_data', ['test_delete_circuit'], indirect=True)
    def test_delete_circuit(self, ssot, test_data):
        """ Circuits - Delete a Circuits by model. """
        for row in test_data['data']:
            found_contact = ssot.search_circuit(row['CIRCUIT_ID'])
            assert found_contact, f"No circuit with name {row['CIRCUIT_ID']} found."
            ssot.delete_tenant(row['CIRCUIT_ID'])
            assert ssot.check_alert_text(self.DELETE), f"The alert text is not {self.DELETE} as we expected."


@pytest.mark.exports
class TestCircuitsExports:
    @pytest.mark.parametrize('test_data', ['test_export_circuits'], indirect=True)
    def test_export_circuits(self, ssot, test_data, rename_download):
        """ circuits - export csv the current view. """
        ssot.circuits_page()
        ssot.click_export_button()
        ssot.export_current_view()

    @pytest.mark.parametrize('test_data', ['test_check_export_circuits'], indirect=True)
    def test_check_export_circuits(self, ssot, test_data, rename_download):
        """ circuits - chek the csv in local machine"""
        ssot.circuits_page()
        data = ssot.get_data_for_check_export(2)
        file_name = 'circuits_export.csv'
        rename_download(name = file_name)
        file_path = os.path.join(os.getcwd(), file_name)
        assert os.path.isfile(file_path), "The file_path not present in root described in isfile."
        csv = ssot.read_csv(file_name)
        assert ssot. check_csv_and_data(data, csv)
        os.remove(file_path)