"""
Test Folder for the SSoT: Inventory UI testing
"""
