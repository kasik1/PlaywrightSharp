"""
This suite tests the functionality for: SSoT: Inventory UI
"""
import os

import pytest


@pytest.mark.parallel
@pytest.mark.functional
class TestInventory:
    """
    Testing Class for: SSoT: Inventory UI
    """

    def setup(self):
        """
        Sets the initial variables for the test cases
        """
        self.added_inventory_item = "Added 1 inventory items to 1 devices."
        self.error_messages = {
            'added_alert_not_found': "The added alert is not present.",
            'devices_not_found': 'Devices were not found to continue with testing',
            'items_not_found': 'Inventory items were not found to continue with testing',
            'expected_alert_message': 'Message from expected alert was not found',
            'alert_not_found': 'Expected alert was not found',
        }
        self.edited_inventory_item = 'Updated 1 inventory items'
        self.deleted_inventory_item = 'Deleted 1 inventory items'
        self.ADD_OK = "Created contact"
        self.UPDATE = "Modified contact"
        self.DELETE = "Deleted contact"
        self.CREATE_IMG = "Created image attachment"
        self.DELETE_IMG = "Deleted image attachment"
        self.UPDATE_IMG = "Modified image attachment"

    @pytest.mark.parametrize('test_data', ['test_create_item'], indirect=True)
    def test_create_item(self, ssot, test_data, setup_server_url):
        """
        Asserts the creation of a inventory item for a device
        :param ssot: Instance of the module's Page Object Model
        :param test_data: Test Data for the test case
        """
        for row in test_data['data']:
            ssot.go_url(setup_server_url)
            ssot.devices_page()
            ssot.select_device_checkbox()
            ssot.add_component(name='Inventory Items')
            ssot.fill_inventory_item_form(data=row)
            ssot.click_submit_button()
            assert ssot.check_alert_text(self.added_inventory_item), self.error_messages['expected_alert_message']

    @pytest.mark.parametrize('test_data', ['test_view_item_created'], indirect=True)
    def test_view_item_created(self, ssot, test_data):
        """
        Asserts that an Inventory item was created
        :param ssot: Instance of the module's Page Object Model
        :param test_data: Test Data for the test case
        """
        for row in test_data['data']:
            ssot.devices_page()
            ssot.select_device_checkbox()
            ssot.add_component(name='Inventory Items')
            asset_tag = ssot.fill_inventory_item_form(data=row)
            ssot.click_submit_button()
            assert ssot.alert_is_present(), self.error_messages['added_alert_not_found']
            assert ssot.check_alert_text(self.added_inventory_item), self.error_messages['expected_alert_message']
            ssot.inventory_items_page()
            assert ssot.check_inventory_item_assert_tag(asset_tag)
            ssot.search_field("Test Item")
            ssot.select_checkbox_search()
            ssot.delete_item_selected()
            ssot.click_confirm_button()

    @pytest.mark.parametrize('test_data', ['test_view_inventory_details'], indirect=True)
    def test_view_inventory_details(self, ssot, test_data):
        """ inventory - View site details """
        ssot.inventory_items_page()
        ssot.view_first_inventory()
        ssot.is_inventory_description_present()

    @pytest.mark.parametrize('test_data', ['test_view_inventory_tab'], indirect=True)
    def test_view_inventory_tab(self, ssot, test_data):
        """ inventory - View device titles in inventory details """
        ssot.inventory_items_page()
        ssot.view_first_inventory()
        assert ssot.is_tab_inventory_present()

    @pytest.mark.parametrize('test_data', ['test_view_change_log'], indirect=True)
    def test_view_change_log(self, ssot, test_data):
        """ View the change log table for a record """
        ssot.devices_menu()
        ssot.inventory_items_page()
        ssot.view_first_inventory()
        ssot.go_to_tab('Change Log')
        assert ssot.is_log_table_present()

    @pytest.mark.parametrize('test_data', ['test_edit_inventory_item'], indirect=True)
    def test_edit_inventory_item(self, ssot, test_data):
        """
        Asserts the edition of an Inventory item
        :param ssot: Instance of the module's Page Object Model
        :param test_data: Test Data for the test case
        """
        for row in test_data['data']:
            ssot.inventory_items_page()
            ssot.select_item_checkbox()
            ssot.edit_item_selected()
            ssot.fill_edit_inventory_item_form(row)
            ssot.click_apply_button()
            assert ssot.check_update() == "Updated 1 inventory items"

    @pytest.mark.parametrize('test_data', ['test_delete_inventory_item'], indirect=True)
    def test_delete_inventory_item(self, ssot, test_data):
        """
        Asserts the delete of an Inventory item
        :param ssot: Instance of the module's Page Object Model
        :param test_data: Test Data for the test case
        """
        ssot.inventory_items_page()
        ssot.select_item_checkbox()
        ssot.delete_item_selected()
        ssot.click_confirm_button()
        assert ssot.check_delete()

    @pytest.mark.parametrize('test_data', ['test_search_item_with_filters'], indirect=True)
    def test_search_item_with_filters(self, ssot, test_data):
        """
        Asserts the search of an Inventory item
        :param ssot: Instance of the module's Page Object Model
        :param test_data: Test Data for the test case
        """
        ssot.inventory_items_page()
        asset_tag = ssot.get_asset_from_table()
        ssot.search_field(asset_tag)
        assert ssot.check_inventory_item_assert_tag(asset_tag)


@pytest.mark.exports
class TestInventoryExports:
    @pytest.mark.parametrize('test_data', ['test_export_inventory'], indirect=True)
    def test_export_inventory(self, ssot, test_data, rename_download):
        """ device - export csv the current view. """
        ssot.inventory_items_page()
        ssot.click_export_with_two_buttons()
        ssot.export_current_view()

    @pytest.mark.parametrize('test_data', ['test_check_export_inventory'], indirect=True)
    def test_check_export_inventory(self, ssot, test_data, rename_download):
        """ device - chek the csv in local machine"""
        ssot.inventory_items_page()
        data = ssot.get_data_for_check_export(2)
        file_name = 'inventory_export.csv'
        rename_download(name=file_name)
        file_path = os.path.join(os.getcwd(), file_name)
        assert os.path.isfile(file_path), "The file_path not present in root described in isfile."
        csv = ssot.read_csv(file_name)
        assert ssot. check_csv_and_data(data, csv)
        os.remove(file_path)