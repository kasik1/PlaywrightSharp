import pytest


@pytest.mark.smoke
class TestGeneralSearchTool:
    """Class for the General search tool in ssot"""

    @pytest.mark.parametrize('test_data', ['test_search_nav'], indirect=True)
    def test_search_nav(self, ssot, test_data):
        """ search in seach box the nav. """
        for row in test_data['data']:
            ssot.set_search_nav(row['NAME'])
            objects, _ = ssot.get_objects()
            assert objects is not None, f"the search failed because the {row['NAME']}"

    @pytest.mark.parametrize('test_data', ['test_search_options'], indirect=True)
    def test_search_options(self, ssot, test_data):
        """ specific search on a specific module"""
        for row in test_data['data']:
            ssot.set_search_nav(row['NAME'])
            objects, _ = ssot.get_objects()
            for object in objects:
                result, option, _ = ssot.select_object(object, row['NAME'])
                assert result, f"the search failed because the {row['NAME']} value does not exist in the object {option}"

    @pytest.mark.parametrize('test_data', ['test_assert_number_search_results'], indirect=True)
    def test_assert_number_search_results(self, ssot, test_data, setup_server_url):
        """performs a specific search in a specific module and counts the search rows and compares them
         with the result that the search engine gives per module"""
        for row in test_data['data']:
            ssot.set_search_nav(row['NAME'])
            objects, rows_number = ssot.get_objects()
            for object in objects:
                result, option, result_rows = ssot.select_object(object, row['NAME'], count_row=True)
                ssot.set_search_nav(row['NAME'])
                row_number = ssot.line_search(object)
                assert row_number == result_rows, "the number of rows shown in the search " \
                                               "does not match, with the real number of elements that exist in the module"
