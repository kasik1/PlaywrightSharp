from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from .ssot import SSOTPage, SSoT
from tests.pom.selectors.bulk_snow import BulkSnow as Bulk


class SSOTBulkSnow(SSOTPage, SSoT):
    """contains the function"""

    def checkbox_multi(self):
        array = []
        for i in range(1, 3):
            locator = (By.XPATH, f"(//td/input[@type='checkbox'])[{i}]")
            self.get_element(locator)
            self.click_on_element(locator)
            name_locator = (By.XPATH, f"(//td/input[@type='checkbox'])[{i}]/../../td[2]/a")
            name = self.get_element(name_locator).text
            array.append(name)
        return array

    def button_ci(self):
        locator = (By.NAME, "_bulk_create")
        self.get_element(locator)
        self.click_on_element(locator)

    def check_request(self, name, value):
        locator = (By.XPATH, f"//td[4]/a[contains(text(),'{name}')]")
        value_name = self.get_element(locator).text
        request_type = (By.XPATH, f"//td[4]/a[contains(text(),'{name}')]/../../td[6]")
        value_req_type = self.get_element(request_type).text
        assert value_name == name

    def button_edit(self):
        locator = (By.NAME, "_edit")
        self.get_element(locator)
        self.click_on_element(locator)

    def edit_data(self, data):
        locator = (By.XPATH, "//strong[contains(text(), 'Attributes')]")
        self.get_element(locator)
        self.set_select_data(Bulk.service_now_assig, data['ASSIGNMENT_GROUP'])
        self.set_select_data(Bulk.device_type, data['DEVICE_TYPE'])
        self.click_on_element((By.XPATH, "//button[contains(text(), 'Apply')]"))

    def button_decom(self):
        locator = (By.NAME, "_bulk_decom")
        self.get_element(locator)
        self.click_on_element(locator)

    def get_devices(self) -> list:
        """Returns a list of devices.
        Returns:
            Devices list (list): List of devices"""
        try:
            rows = self.get_elements(SSoT.rows_selector)
            devices = []
            for row in range(1, len(rows)+1):
                columns = self.get_elements((By.XPATH, f"//table[@class='table table-hover table-headings']/tbody/tr[{row}]/td"))
                _, name, status, tenant, role, _, site, _, _ = [column.text.strip() for column in columns]
                devices.append(dict(NAME=name, STATUS=status, ROLE=role, SITE=site, TENANT=tenant))
            return devices
        except (TimeoutException, ValueError):
            return []

    def search_device(self, field: str, row="NAME") -> bool:
        """Returns if found a device by a specific row.
        Parameters:
            field (str): A specific field to found.
            row (str): A specific row to found the field.
        Returns:
            bool (bool): If the field was found. """
        self.input_search_filters(field)
        self.search_button_filters()
        elements = self.get_devices()
        return any([True if element[row] in field else False for element in elements])

    def show_production_button(self):
        locator = (By.NAME, '_bulk_prod_move')
        return self.get_element(locator)

    def show_preprod_button(self):
        locator = (By.NAME, '_bulk_pre_prod_move')
        return self.get_element(locator)

    def check_element(self):
        locator = (By.XPATH, f"(//td/input[@type='checkbox'])[1]")
        self.get_element(locator)
        self.click_on_element(locator)

    def production_button(self):
        locator = (By.NAME, '_bulk_prod_move')
        self.get_element(locator)
        self.click_on_element(locator)

    def preprod_button(self):
        locator = (By.NAME, '_bulk_pre_prod_move')
        self.get_element(locator)
        self.click_on_element(locator)

    def check_status(self, name):
        locator = (By.XPATH, f"//td/a[contains(text(),'{name}')]/../following-sibling::td[1]/label")
        status = self.get_element(locator)
        print(status.text)
        return status.text