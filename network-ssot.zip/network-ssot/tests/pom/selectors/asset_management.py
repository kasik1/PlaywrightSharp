from selenium.webdriver.common.by import By


class SSoTAssetManagement:
    """Selectors for the contact module"""
    name_title = (By.XPATH, "//label[@for='id_name']")
    name_input = (By.ID, "id_name")
    location_select = (By.XPATH, "//select[@id='id_location']/following-sibling::span/span/span/span[1]")
    device_type_select = (By.XPATH, "//select[@id='id_device_type']/following-sibling::span/span/span/span[1]")
    role_select = (By.XPATH, "//select[@id='id_role']/following-sibling::span/span/span/span[1]")
    comments_input = (By.ID, "id_comments")
