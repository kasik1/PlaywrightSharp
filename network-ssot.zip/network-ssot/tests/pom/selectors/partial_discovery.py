from selenium.webdriver.common.by import By


class PartialDiscover:
    button_submit = (By.XPATH, "//button[contains(text(),'Submit')]")
    text_area = (By.NAME, "data")

