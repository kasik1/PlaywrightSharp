from selenium.webdriver.common.by import By


class SSoTPlatform:
    """Selectors for the plataform"""

    name_input = (By.ID, "id_name")
    manufacturer_selector = (By.XPATH, "//select[@id='id_manufacturer']/../span/span/span/span[1]")
    napalm_driver_selector = (By.NAME, "napalm_driver")
    desc = (By.ID, "id_description")
