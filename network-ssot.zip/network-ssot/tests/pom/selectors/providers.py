from selenium.webdriver.common.by import By


class SSoTProviders:
    """Selectors for the circuits"""

    name_provider = (By.ID, "id_name")
    asn_provider = (By.ID, "id_asn")
    account_number = (By.ID, "id_account")
    comment_provider = (By.ID, "id_comments")
