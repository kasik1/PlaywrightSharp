from selenium.webdriver.common.by import By


class SSoTSnow:
    """Selectors for the service now module"""

    title_portal_snow = (By.CLASS_NAME, "title")
    search_portal = (By.XPATH, "//header/div[1]/div[1]/div[2]/div[1]/div[4]/form[1]/div[1]/label[1]/span[1]")
    input_portal = (By.ID, "sysparm_search")
    input_number = (By.ID, "sys_readonly.sc_request.number")
    input_service_rec = (By.ID, "sys_display.sc_request.requested_for")
    input_primary_contact = (By.ID, "sys_display.sc_request.u_primary_cntct")
    button_cancel = (By.NAME, "_cancel_snow_requests")
    button_pending = (By.NAME, "_set_requests_to_pending")
    requested_item = (By.XPATH, "//a[contains(text(),'RIT')][1]")
    download_snow = (By.XPATH, "//a[contains(text(),'servicenow-')]")
    download_monitoring = (By.XPATH, "//a[contains(text(),'monitoring-')]")
    button_send = (By.NAME, "_send_pending_requests")
