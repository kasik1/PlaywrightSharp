from selenium.webdriver.common.by import By


class SSoTLocations:
    """Selectors for the site module"""
    name_selector = (By.NAME, "name")
    location_type = (By.XPATH, "//select[@id='id_location_type']/../span/span/span/span[1]")
    locator_code_selector = (By.NAME, "locator_code")
    status_selector = (By.XPATH, "//select[@id='id_status']/../span/span/span/span[1]")
    region_selector = (By.XPATH, "//select[@id='id_region']/following-sibling::div/div/span[1]")
    facility_selector = (By.ID, "id_facility_type")
    ownership_type_selector = (By.ID, "id_ownership_type")
    facility = (By.ID, "id_facility")
    description_selector = (By.NAME, "description")
    property_id = (By.NAME, "cf_Property ID")
    primary_use = (By.NAME, "cf_Primary Use")
    clasif = (By.NAME, "cf_Site Classification")
    id_physical_adress = (By.ID, "id_physical_address")
    locator_code = (By.ID, "id_cf_snow_sys_id")
    country_selector = (By.NAME, "cf_Country")
    city_selector = (By.NAME, "cf_City")
    state_selector = (By.NAME, "cf_State")
    zip_selector = (By.NAME, "cf_Zip")
    comments_selector = (By.NAME, "comments")

