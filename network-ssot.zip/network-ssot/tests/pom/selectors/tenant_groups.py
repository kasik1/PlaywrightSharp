from selenium.webdriver.common.by import By


class SSoTTenantGroup:
    """Selectors for the tenants group module"""

    parent_selector = (By.XPATH, "//select[@id='id_parent']/following-sibling::span")
    name_selector = (By.NAME, "name")
    description_selector = (By.NAME, "description")
    edit_tenant_group = (By.CSS_SELECTOR, "i.mdi.mdi-pencil")
    delete_tenant_group = (By.CSS_SELECTOR, "i.mdi.mdi-trash-can-outline")
