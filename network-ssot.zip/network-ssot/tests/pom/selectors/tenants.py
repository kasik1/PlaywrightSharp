from selenium.webdriver.common.by import By


class SSoTTenant:
    """Selectors for the tenant module"""

    group_selector = (By.XPATH, "//select[@id='id_tenant_group']/following-sibling::span")
    input = (By.XPATH, "//body/div[1]/main[1]/div[1]/div[3]/div[1]/div[1]/form[1]/div[1]/div[4]/div[1]/div[1]/div[2]/div[1]/input[1]")
    name_selector = (By.NAME, "name")
    description_selector = (By.NAME, "description")
    comments_selector = (By.NAME, "comments")
    search_button = (By.ID, "button-search-magnifier")
    edit_tenant_group = (By.XPATH, "//tbody/tr[2]/td[5]/a[2]")
    delete_tenant_group = (By.XPATH, "//tbody/tr[2]/td[5]/a[3]")
