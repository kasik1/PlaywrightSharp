from selenium.webdriver.common.by import By


class SSoTInventorySelectors:
    """Selectors for the inventory module"""

    def set_value(self, value):
        self.value = value

    def get_value(self):
        return self.value

    manufacturer_select = (By.NAME, 'manufacturer')
    manufacturer_select_option_1 = (By.XPATH, "(//select/option[@selected]/following-sibling::option)[1]")
    inventory_items_not_found = (By.XPATH, "//td[contains(text(), '— No inventory items found —')]")
    items_first_check_box = (By.XPATH, "(//tbody/tr/td/input[@type='checkbox'])[1]")
    checkbox_search = (By.XPATH, "(//tbody/tr/td/a[contains(text(),'Test Item')][1])/../../td[1]")
    edit_selected_button = (By.XPATH, "//div[2]/div/button[1]")
    action_button = (By.XPATH, "//div/button[2]/span[2]")
    delete_option = (By.NAME, "_delete")
    edited_manufacturer_select = (By.XPATH, "//span/b[@role='presentation']")
    edited_manufacturer_select_option_1 = (By.XPATH, "//ul[@id='select2-id_manufacturer-results']/li[1]")
    apply_button_selector = (By.NAME, "_apply")
    table_headers = (By.XPATH, "//th/a")
    search_input = (By.ID, "q-search")
    apply_filters = (By.ID, "butto-apply-search")
    return_value = (By.XPATH, "//td[contains(text(),'Return Value')]/following-sibling::td")

    @property
    def table_header_asset_tag(self):
        selector = (By.XPATH, "(//tr/td[not(@class='min-width')])[" + str(self.get_value()) + "]")
        return selector

    @property
    def inventory_form_input(self):
        selector = (By.NAME, self.get_value())
        return selector

    @property
    def asset_tag(self):
        selector = (By.XPATH, "//tr/td[contains(text(), '" + self.get_value() + "')]")
        return selector
