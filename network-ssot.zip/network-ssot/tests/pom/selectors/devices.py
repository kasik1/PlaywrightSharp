from selenium.webdriver.common.by import By


class SSoTDevices:
    """Selectors for the devices module"""

    def set_value(self, value):
        self.value = value

    def get_value(self):
        return self.value

    name_selector = (By.NAME, "name")
    device_role_selector = (By.XPATH, "//select[@id='id_role']/../span/span/span/span[1]")
    manufacturer_selector = (By.XPATH, "//select[@id='id_manufacturer']/../span/span/span/span[1]")
    device_type_selector = (By.XPATH, "//select[@id='id_device_type']/../span/span/span/span[1]")
    serial_number_selector = (By.NAME, "serial")
    asset_tag_selector = (By.NAME, "asset_tag")
    site_selector = (By.XPATH, "//select[@id='id_location']/../span/span/span/span[1]")
    rack_selector = (By.XPATH, "//select[@id='id_rack']/../span/span/span/span[1]")
    status_selector = (By.XPATH, "//select[@id='id_status']/../span/span/span/span[1]")
    platform_selector = (By.XPATH, "//select[@id='id_platform']/../span/span/span/span[1]")
    primary_ip4_selector = (By.NAME, "primary_ip4")
    comments_selector = (By.NAME, 'comments')
    devices_first_check_box = (By.XPATH, "(//tbody/tr/td/input[@type='checkbox'])[1]")
    devices_not_found = (By.XPATH, "//td[contains(text(), '— No devices found —')]")
    add_component_button = (By.XPATH, "//button[text()= ' Add Components ']")
    name_pattern_inventory = (By.NAME, "name_pattern")
    label_pattern_inventory = (By.NAME, "label_pattern")
    inventory_manufacture = (By.XPATH, "//select[@id='id_manufacturer']/following-sibling::div/div/span[1]")
    snow_device_type = (By.XPATH, "//select[@id='id_cf_ServiceNow Device Type']/following-sibling::div/div/span[1]")
    tags_selector = (By.XPATH, "//select[@id='id_tags']/../span/span")

    @property
    def components_option(self):
        selector = (By.XPATH, f"//li/a[@class='formaction' and contains(text(),'" + self.get_value() + "')]")
        return selector
