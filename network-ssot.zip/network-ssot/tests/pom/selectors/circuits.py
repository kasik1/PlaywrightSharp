from selenium.webdriver.common.by import By


class SSoTCircuits:
    """Selectors for the circuits"""

    provider_selector = (By.XPATH, "//select[@id='id_provider']/../span/span/span/span[1]")
    circuit_id = (By.ID, "id_cid")
    type_selector = (By.XPATH, "//select[@id='id_circuit_type']/../span/span/span/span[1]")
    status_selector = (By.XPATH, "//select[@id='id_status']/../span/span/span/span[1]")
    comments_circuit = (By.ID, "id_comments")
