from selenium.webdriver.common.by import By


class SSoTCDevicesTypes:
    """Selectors for the devices type module"""

    manufacturer_selector = (By.XPATH, "//select[@id='id_manufacturer']/../span/span/span/span[1]")
    status_selector = (By.XPATH, "//select[@id='id_subdevice_role']/../span/span/span/span[1]")
    height_input_selector = (By.ID, 'id_u_height')
    model_selector = (By.NAME, "model")
    part_number_selector = (By.NAME, "part_number")
    tag_comp = (By.XPATH, "//li[@role='presentation']/a[contains(text(), '{}')]")
    component = (By.XPATH, "//strong[contains(text(),'{}')]/../following-sibling::div/div/a")
    name_interface = (By.NAME, "name_pattern")
    label_interface = (By.NAME, "label_pattern")
    edit_name_interface = (By.NAME, "name")
    edit_label_interface = (By.NAME, "label")
