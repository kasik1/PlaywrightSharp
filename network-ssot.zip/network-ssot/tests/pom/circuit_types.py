from selenium.webdriver.common.by import By
from .ssot import SSOTPage
from tests.pom.selectors.circuit_types import SSoTCircuitTypes as SSoTCirType


class SSOTCircuitTypes(SSOTPage):
    """contains the functions to run the tenants module"""

    def add_circuit_types(self, data):
        """Add a Circuit."""
        self.circuit_types_page()
        self.click_add_button()
        self.set_circuit_types_data(data)
        self.click_submit_button()

    def set_circuit_types_data(self, data):
        """Sets the data for the Circuit inputs."""
        self.get_element(SSoTCirType.name_circuit)
        self.set_text(SSoTCirType.name_circuit, data['NAME'])
        self.set_text(SSoTCirType.desc_circuit, data['DESC'])

    def view_change_log_circuit_types(self, name):
        """Edit a manufacturer."""
        log, _, _ = self.get_circuit_types_buttons_by_name(name)
        log.click()

    def edit_circuit_types(self, name, data):
        """Edit a role."""
        _, edit, _ = self.get_circuit_types_buttons_by_name(name)
        edit.click()
        self.set_circuit_types_data(data)
        self.click_update_button()

    def delete_circuit_types(self, name):
        """delete a circuit types."""
        _, _, delete = self.get_circuit_types_buttons_by_name(name)
        delete.click()
        self.click_confirm_button()

    def check_required_input(self, rows_get):
        rows_value = []
        for row in rows_get:
            locator = (By.NAME, f"{row}")
            element = self.get_element(locator)
            value = element.get_attribute('defaultValue')
            rows_value.append(value)
        return rows_value