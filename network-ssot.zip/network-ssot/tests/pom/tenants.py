from .ssot import SSOTPage
from selenium.webdriver.common.by import By
from tests.pom.selectors.tenants import SSoTTenant as SSoTT


class SSOTTenants(SSOTPage):
    """contains the functions to run the tenants module"""

    def add_tenant(self, data):
        """Add a Tenant."""
        self.tenant_page()
        self.click_add_button()
        self.set_tenant_data(data)
        self.click_submit_button()

    def view_first_tenant(self):
        locator = (By.XPATH, '(//table/tbody/tr/td/a)[1]')
        name = self.get_element(locator).text
        self.click_on_element(locator)
        return name

    def is_tenant_description_present(self, name):
        locator = (By.XPATH, f"//li/a[text()='{name}']")
        return self.get_element(locator)

    def are_tenant_stats_present(self):
        modules = ['Locations', 'Racks', 'Rack Reservations', 'Devices', 'VRFs', 'Prefixes', 'IP Addresses',
                   'VLANs', 'Circuits', 'Virtual Machines', 'Clusters']
        for module in modules:
            xpath = f"//strong[contains(text(),'Stats')]/parent::div/following-sibling::div//p[contains(text(), '{module}')]"
            locator = (By.XPATH, xpath)
            element = self.find_elements(locator)
            assert element, f'Tenant stats for {module} module is not present'

    def set_tenant_data(self, data):
        """Sets the data for the Tenant inputs."""
        self.get_element(SSoTT.name_selector)
        self.set_text(SSoTT.name_selector, data['FIRST_NAME'])
        self.set_select_data(SSoTT.group_selector, data['GROUP'])
        self.set_text(SSoTT.description_selector, data['DESCRIPTION'])
        self.set_text(SSoTT.comments_selector, data['COMMENTS'])

    def search_tenant(self, field):
        """Returns if found a Tenant by a specific row.
        Parameters:
            field (str): A specific field to found.
            row (str): A specific row to found the field.
        Returns:
            bool (bool): If the field was found. """

        self.tenant_page()
        self.input_search_filters(field)
        self.search_button_filters()

    def edit_tenant(self, tenants, data):
        """Edit a Tenant."""
        self.click_link_text(tenants)
        self.click_edit_button()
        self.set_tenant_data(data)
        self.click_update_button()

    def delete_tenant(self, model):
        """Delete a Tenant."""
        self.click_link_text(model)
        self.click_delete_button()
        self.click_confirm_button()