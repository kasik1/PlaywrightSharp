from selenium.common.exceptions import TimeoutException, \
    ElementClickInterceptedException, StaleElementReferenceException, NoSuchElementException
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from ..commons.functions import LocateBy
import time


class Page:

    def __init__(self, driver):
        self.driver = driver

    def set_text(self, locator, text, enter=False, ssot_wait=False, down=False, timeout=20, sec=1):
        element = self.get_element(locator, timeout)
        element.clear()
        element.send_keys(text)
        if enter:
            if ssot_wait:
                time.sleep(sec)
                if down:
                    element.send_keys(Keys.ARROW_DOWN)
            element.send_keys(Keys.ENTER)

    def get_element(self, locator, timeout=35, highlight=True):
        wait = WebDriverWait(self.driver, timeout)
        try:
            element = wait.until(EC.presence_of_element_located(locator))
        except (StaleElementReferenceException, NoSuchElementException):
            element = self.driver.find_element(*locator)
        except TimeoutException:
            assert False, f'element with locator {locator} was not present'
        if highlight:
            self.highlight_element(element)
        return element

    def get_elements(self, locator, timeout=30):
        wait = WebDriverWait(self.driver, timeout)
        try:
            elements = wait.until(
                EC.presence_of_all_elements_located(locator))
        except TimeoutException as e:
            raise TimeoutException from e
        return elements

    def text_in_element(self, locator, text, timeout=15):
        wait = WebDriverWait(self.driver, timeout)
        try:
            is_present = wait.until(
                EC.text_to_be_present_in_element(locator, text))
        except TimeoutException:
            return False
        return is_present

    def _presence_of_elements(self, by, selector, timeout):
        wait = WebDriverWait(self.driver, timeout)
        try:
            element = wait.until(EC.presence_of_all_elements_located((by, selector)))
        except TimeoutException as e:
            raise TimeoutException from e
        return element

    def _presence_of_element(self, by, selector, timeout):
        wait = WebDriverWait(self.driver, timeout)
        try:
            element = wait.until(EC.presence_of_element_located((by, selector)))
        except TimeoutException as e:
            raise TimeoutException from e
        return element

    def check_presence_of_element(self, locator, timeout):
        wait = WebDriverWait(self.driver, timeout)
        try:
            element = wait.until(EC.presence_of_element_located((locator)))
        except TimeoutException as e:
            return False
        return element

    def _get_element_explicitly(self, locate_by, selector, timeout):
        if locate_by == LocateBy.XPATH:
            element = self._presence_of_element(By.XPATH, selector, timeout)
        elif locate_by == LocateBy.CSS:
            element = self._presence_of_element(By.CSS_SELECTOR, selector, timeout)
        return element

    def _get_elements_explicitly(self, locate_by, selector, timeout):
        if locate_by == LocateBy.XPATH:
            element = self._presence_of_elements(By.XPATH, selector, timeout)
        elif locate_by == LocateBy.CSS:
            element = self._presence_of_elements(By.CSS_SELECTOR, selector, timeout)
        return element

    def _text_in_element_present(self, by, selector, text, timeout):
        wait = WebDriverWait(self.driver, timeout)
        try:
            is_present = wait.until(
                EC.text_to_be_present_in_element((by, selector), text))
        except TimeoutException:
            return False
        return is_present

    def click_on_element(self, locator, timeout=35, highlight=True):
        wait = WebDriverWait(self.driver, timeout)
        try:
            element = wait.until(
                EC.element_to_be_clickable(locator))
            if highlight:
                self.highlight_element(element)
            element.click()
        except TimeoutException as e:
            raise TimeoutException from e
        except (
                ElementClickInterceptedException,
                StaleElementReferenceException):
            self.click_on_element_by_js(locator)

    def select_element(self, locator, option, timeout=25):
        element = self.get_element(locator, timeout)
        select = Select(element)
        select.select_by_visible_text(option)

    @staticmethod
    def get_input_text(input_element):
        return input_element.get_attribute('value')

    def click_on_element_by_js(self, locator, timeout=30):
        element = self.get_element(locator, timeout)
        js_command = 'arguments[0].click();'
        self.driver.execute_script(js_command, element)

    def refresh_page(self):
        self.driver.refresh()

    def send_enter_key(self, input_locator):
        element = self.get_element(input_locator)
        element.send_keys(Keys.ENTER)

    def find_elements(self, locator):
        elements = self.driver.find_elements(*locator)
        return elements

    def find_element(self, locator):
        try:
            element = self.driver.find_element(*locator)
            self.highlight_element(element)
            return element
        except:
            html = self.print_html()
            print("html print:", html)

    @staticmethod
    def get_format_selector(selector, item):
        """Returns a formatted selector.

        Returns:
            selector: Returns a formatted selector.
        """
        tem_selector = selector[1].format(item)
        return selector[0], tem_selector

    def is_element_present(self, locator):
        try:
            self.driver.find_element(*locator)
        except:
            return False
        return True

    def get_url(self):
        return self.driver.current_url

    def go_url(self, url):
        try:
            self.driver.get(url)
        except:
            self.refresh_page()
            time.sleep(5)
            self.driver.get(url)
            print(self.driver.page_source)

    def back_page(self):
        self.driver.back()

    def close_new_tab(self, name):
        if self.driver.title == f"{name} | Request | ServiceNow":
            time.sleep(2)
            self.driver.close()

    @staticmethod
    def apply_style(driver, element, style):
        driver.execute_script("arguments[0].setAttribute('style', arguments[1]);", element, style)

    def highlight_element(self, element, effect_time=.3, color='yellow', border='3'):
        """
        Highlights a Selenium Webdriver element
        :param element: The DOM element from the page
        :param effect_time: The time that element is going to be highlighted
        :param color: Color for the highlight
        :param border: Size of the border
        :return:
        """
        driver = element._parent
        original_style = element.get_attribute('style')
        self.apply_style(driver, element, "border: {0}px solid {1};".format(border, color))
        time.sleep(effect_time)
        self.apply_style(driver, element, original_style)

    def page_status(self, timeout=120):

        wait = WebDriverWait(self.driver, timeout)
        try:
            is_completed = wait.until(
                lambda driver: driver.execute_script('return document.readyState') == 'complete')
            print(is_completed)
        except TimeoutException:
            return False
        return is_completed

    def print_html(self):
        return self.driver.page_source

    def is_element_clickable(self, locator, timeout=35):
        wait = WebDriverWait(self.driver, timeout)
        try:
            element = wait.until(EC.element_to_be_clickable(locator))
        except TimeoutException as e:
            return False
        return element
