from datetime import datetime
# from ndosecrets import get_secret
import requests


class ZephyrAPI:

    def __init__(self):
        self.server = None
        self.project_id = None
        self._token = None
        self.get_info()

    def get_info(self):
        # TODO read credentials when zephyr is enabled again
        # zephyr_secrets = get_secret('portal_testing_zephyr')
        self.server = ''  # zephyr_secrets['zephyr_server']
        self._token = ''  # zephyr_secrets['zephyr_token']
        self.project_id = ''  # zephyr_secrets['zephyr_project_id']

    def get_headers(self):
        headers = {
            'Content-type': 'application/json',
            'Authorization': f'Bearer {self._token}'}
        return headers

    def get_releases_from_project(self, project_id):
        """
        :param project_id: Project ID
        :return: A request object with the releases from the project
        """
        endpoint = f'/flex/services/rest/latest/release/paged/project/{project_id}'
        url = self.server + endpoint
        response = requests.get(url, headers=self.get_headers())
        return response

    def get_cycle(self, cycle_id):
        """
        :param cycle_id: Get the Cycle details and the cycle-phases
        :return: A requests object with the Cycle
        """
        endpoint = f'/flex/services/rest/latest/cycle/{cycle_id}'
        url = self.server + endpoint
        response = requests.get(url, headers=self.get_headers())
        return response

    def get_cycle_for_release(self, release_id):
        """
        Getcycle for release with respect to releaseid
        :param release_id: The release id. Can be founded in zephyr in the url by selecting the release name
        :return: All the cycles from the release each one with its cycle phases
        """
        endpoint = f'/flex/services/rest/latest/cycle/release/{release_id}'
        url = self.server + endpoint
        response = requests.get(url, headers=self.get_headers())
        return response

    def get_tcr_catalog_tree(self, tcr_catalog_tree_id, filter_by_test_case_name=None):
        """
        :param tcr_catalog_tree_id: Test Case Repository Tree Id, can be found under the get_cycle endpoint and
                                    each cycle phase has it:
                                        "cyclePhases": [
                                            {
                                                "id": 6878,
                                                "name": "opsready",
                                                "tcrCatalogTreeId": 366677,
        :return: A requests object with the TCR Catalog Tree
        """
        endpoint = f'/flex/services/rest/latest/testcase/planning/{tcr_catalog_tree_id}'
        if filter_by_test_case_name:
            filters = "?offset=0&pagesize=50&dbsearch=true&isascorder=true&order=orderId&frozen=false&is_cfield=false" \
                      "&tcname=" + filter_by_test_case_name
            endpoint += filters
        url = self.server + endpoint
        response = requests.get(url, headers=self.get_headers())
        return response

    def get_test_case_usage_history(self, test_case_id):
        """
        :param test_case_id: The Test Case ID from the UI
        :return: A requests object with the Usage History
        """
        endpoint = f'/flex/services/rest/latest/tcuh/testcase/{test_case_id}'
        url = self.server + endpoint
        response = requests.get(url, headers=self.get_headers())
        return response

    def get_release_test_schedule_id(self, tcr_catalog_tree_id, test_case_id, test_case_name):
        response = self.get_tcr_catalog_tree(tcr_catalog_tree_id, filter_by_test_case_name=test_case_name)
        results = response.json()['results']
        for result in results:
            if str(test_case_id) == str(result['testcase']['testcaseId']):
                return result['rts']['id']
        return None

    def get_assigned_tester_by_schedule_id(self, schedule_id):
        """
        :param schedule_id: The release test schedule id i.t. rts_id
        :return: The assigned tester id
        """
        endpoint = f'/flex/services/rest/latest/execution/{schedule_id}'
        url = self.server + endpoint
        response = requests.get(url, headers=self.get_headers())
        tester_id = response.json()['testerId']
        return tester_id

    def create_test_case_execution(self, rts_id, status, tester_id, execution_time, notes):
        """
        :param rts_id: Release Test Schedule Id
        :param status: Status or verdict of the test execution
            1 - PASS
            2- FAIL
            3- WIP
            4- Blocked
        :param tester_id: The id in Zephyr from the tester
        :param execution_time: The execution time for a test case
        :param notes: Notes from the test case
        :return: The requests response object
        """
        endpoint = f'/flex/services/rest/latest/execution/{rts_id}'
        params = f'?status={status}&testerid={tester_id}&allExecutions=false&time={execution_time}'
        url = self.server + endpoint + params
        body = {
            'teststepUpdate': False,
            'teststepStausId': 1,
            'notes': notes
        }
        response = requests.put(url, json=body, headers=self.get_headers())
        return response

    def get_current_release(self):
        """
        :param zephyr: A Zephyr Instance object
        :return: The current release id
        """
        releases = self.get_releases_from_project(self.project_id)
        for release in releases.json()['results']:
            start = datetime.strptime(release['releaseStartDate'], '%m/%d/%Y').date()
            end = datetime.strptime(release['releaseEndDate'], '%m/%d/%Y').date()
            today = datetime.today().date()
            if start <= today <= end:
                return release['id']
        return None

    def get_current_cycle_from_release_by_environment(self, release_id, environment):
        """
        :param release_id: The release id
        :return: The current cycle id
        """
        cycles = self.get_cycle_for_release(release_id)
        for cycle in cycles.json():
            start = datetime.strptime(cycle['cycleStartDate'], '%m/%d/%Y').date()
            end = datetime.strptime(cycle['cycleEndDate'], '%m/%d/%Y').date()
            today = datetime.today().date()
            if start <= today <= end:
                if cycle['environment'].lower() == environment:
                    return cycle['id']
        return None

    def get_current_cycle_phase_by_type(self, cycle_id, type):
        response = self.get_cycle(cycle_id)
        cycle_phases = response.json()['cyclePhases']
        for cycle_phase in cycle_phases:
            start = datetime.strptime(cycle_phase['phaseStartDate'], '%m/%d/%Y').date()
            end = datetime.strptime(cycle_phase['phaseEndDate'], '%m/%d/%Y').date()
            today = datetime.today().date()
            if start <= today <= end:
                if cycle_phase['name'].lower() == type:
                    return cycle_phase
        return None
