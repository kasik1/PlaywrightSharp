import csv


class Csv:

    def __init__(self, file_name):
        self._file_name = file_name

    def rows(self, column_index='TEST_TYPE', column_filter_value=''):
        """
        :return records_array: An array of dicts of all the rows
        """
        records_array = []
        with open(self._file_name, mode='r') as csv_file:
            csv_reader = csv.DictReader(csv_file)
            for row in csv_reader:
                if column_filter_value != '':
                    if row[column_index] == column_filter_value:
                        records_array.append(row)
                else:
                    records_array.append(row)
        return records_array
